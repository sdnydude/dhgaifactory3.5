
import React from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar
} from 'recharts';
import { Activity, Server, Terminal, AlertCircle, CheckCircle, ArrowRightCircle } from 'lucide-react';
import { useLiveSystem } from '../contexts/LiveSystemContext';
import { ServiceState } from '../types';

const StatusIcon = ({ status }: { status: ServiceState }) => {
  switch (status) {
    case ServiceState.HEALTHY: return <CheckCircle className="text-emerald-500" size={18} fill="currentColor" fillOpacity={0.2} />;
    case ServiceState.DEGRADED: return <Activity className="text-amber-500" size={18} />;
    case ServiceState.DOWN: return <AlertCircle className="text-red-500" size={18} />;
  }
};

interface DashboardViewProps {
    onAskAssistant?: (prompt: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onAskAssistant }) => {
  const { metrics, events, services } = useLiveSystem();

  return (
    <div className="space-y-6 font-sans pb-10">
      <div className="mb-6">
        <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">System Health</h2>
        <p className="text-gray-500 text-base font-medium">Real-time metrics from Factory 7</p>
      </div>

      {/* Services Grid - Single Row Layout */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {services.slice(0, 4).map((service) => (
          <div key={service.name} className="glass-card p-5 rounded-3xl hover:bg-white/60 transition-colors shadow-sm cursor-default">
            <div className="flex justify-between items-start mb-3">
              <h3 className="text-[11px] font-bold text-gray-400 uppercase tracking-widest truncate mr-2" title={service.name}>{service.name}</h3>
              <StatusIcon status={service.status} />
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold text-gray-900 tracking-tight">{service.latencyMs}</span>
              <span className="text-sm font-semibold text-gray-400">ms</span>
            </div>
            <div className="mt-2 text-xs font-medium text-gray-500">
                Uptime <span className="text-emerald-600">{service.uptime}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Logs Platter - Using real event stream from Context */}
      <div className="glass-card rounded-[2rem] shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-200/50 bg-white/30 backdrop-blur-md flex justify-between items-center">
          <h3 className="text-xs font-bold text-gray-800 flex items-center gap-2">
            <Terminal size={14} className="text-gray-400" />
            Live Event Stream
          </h3>
          <div className="flex items-center gap-2">
            <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
            </span>
            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Connected</span>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <tbody className="divide-y divide-gray-200/50">
              {events.slice(0, 8).map((evt) => (
                <tr key={evt.id} className="hover:bg-white/40 transition-colors group animate-in slide-in-from-left-2 duration-300">
                  <td className="px-3 py-2 font-mono text-[10px] text-gray-400 font-medium whitespace-nowrap w-20">{evt.created_at}</td>
                  <td className="px-3 py-2 font-bold text-gray-700 whitespace-nowrap w-32">{evt.source_service}</td>
                  <td className="px-3 py-2 w-20">
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-black border uppercase tracking-wider ${
                      evt.level === 'ERROR' ? 'bg-red-50 border-red-100 text-red-600' :
                      evt.level === 'WARN' ? 'bg-amber-50 border-amber-100 text-amber-600' :
                      'bg-blue-50 border-blue-100 text-blue-600'
                    }`}>
                      {evt.level || 'INFO'}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-gray-600 font-medium truncate max-w-xs md:max-w-none" title={evt.message || evt.event_type}>
                    {evt.message || evt.event_type}
                  </td>
                  <td className="px-3 py-2 text-right w-24">
                    {(evt.level === 'WARN' || evt.level === 'ERROR') && (
                        <button 
                            onClick={() => onAskAssistant?.(`Analyze this ${evt.level} in ${evt.source_service}: "${evt.message}" and suggest a fix.`)}
                            className="flex items-center gap-1 text-[9px] font-bold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 px-2 py-1 rounded-full transition-colors ml-auto"
                        >
                            Take Action <ArrowRightCircle size={10} />
                        </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Charts Section - Using real metrics stream from Context */}
      <div className="space-y-4">
        {/* GPU Utilization */}
        <div className="glass-card p-4 rounded-[2rem] shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-1.5 bg-[#FF5500]/10 rounded-full">
                <Activity size={14} className="text-[#FF5500]" />
            </div>
            <div>
                <h3 className="text-sm font-bold text-gray-900 leading-none">GPU Utilization</h3>
                <p className="text-[10px] text-gray-500 font-medium">Real-time load (Live)</p>
            </div>
          </div>
          <div className="h-28"> 
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={metrics.gpuUtilization}>
                <defs>
                  <linearGradient id="colorGpu" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF5500" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#FF5500" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#000" strokeOpacity={0.05} vertical={false} />
                <XAxis dataKey="time" stroke="#9ca3af" fontSize={9} tickLine={false} axisLine={false} dy={5} minTickGap={30} hide />
                <YAxis stroke="#9ca3af" fontSize={9} tickLine={false} axisLine={false} dx={-10} domain={[0, 100]} width={25} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(8px)', borderColor: 'rgba(255,255,255,0.5)', color: '#111', borderRadius: '12px', fontSize: '10px', padding: '4px 8px' }}
                  itemStyle={{ color: '#FF5500', fontWeight: 'bold' }}
                />
                <Area 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#FF5500" 
                    strokeWidth={2} 
                    fillOpacity={1} 
                    fill="url(#colorGpu)" 
                    isAnimationActive={true}
                    animationDuration={1500}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* ASR Latency */}
        <div className="glass-card p-4 rounded-[2rem] shadow-sm">
           <div className="flex items-center gap-3 mb-2">
            <div className="p-1.5 bg-indigo-100 rounded-full">
                <Server size={14} className="text-indigo-600" />
            </div>
            <div>
                <h3 className="text-sm font-bold text-gray-900 leading-none">ASR Latency</h3>
                <p className="text-[10px] text-gray-500 font-medium">Processing time per chunk (ms)</p>
            </div>
          </div>
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={metrics.asrLatency}>
                <CartesianGrid strokeDasharray="3 3" stroke="#000" strokeOpacity={0.05} vertical={false} />
                <XAxis dataKey="time" stroke="#9ca3af" fontSize={9} tickLine={false} axisLine={false} dy={5} minTickGap={30} hide />
                <YAxis stroke="#9ca3af" fontSize={9} tickLine={false} axisLine={false} dx={-10} width={30} />
                <Tooltip 
                  cursor={{fill: '#000', opacity: 0.05}}
                  contentStyle={{ backgroundColor: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(8px)', borderColor: 'rgba(255,255,255,0.5)', color: '#111', borderRadius: '12px', fontSize: '10px', padding: '4px 8px' }}
                />
                <Bar dataKey="value" fill="#4F46E5" radius={[4, 4, 4, 4]} barSize={12} isAnimationActive={false} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
