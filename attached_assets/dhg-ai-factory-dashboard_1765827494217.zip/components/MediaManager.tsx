
import React, { useState, useRef } from 'react';
import { FileAudio, FileVideo, Clock, CheckCircle, XCircle, AlertTriangle, Upload, PlayCircle, ChevronRight, X, Save, Filter, ArrowUpDown, Star } from 'lucide-react';
import { MediaStatus, RegistryMedia } from '../types';
import { BrandLogo } from './BrandLogo';
import { useLiveSystem } from '../contexts/LiveSystemContext';

export const MediaManager: React.FC = () => {
  const { mediaItems, registerMedia, updateMediaStatus } = useLiveSystem();
  
  const [isUploading, setIsUploading] = useState(false);
  const [editingItem, setEditingItem] = useState<RegistryMedia | null>(null);
  
  // Sorting and Filtering State
  const [filterStatus, setFilterStatus] = useState<MediaStatus | 'ALL'>('ALL');
  const [sortBy, setSortBy] = useState<'DATE_NEW' | 'DATE_OLD' | 'STATUS' | 'TYPE'>('DATE_NEW');

  // Favorites State with LocalStorage Persistence
  const [favorites, setFavorites] = useState<Set<string>>(() => {
    try {
        const saved = localStorage.getItem('dhg_media_favorites');
        return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch (e) {
        return new Set();
    }
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    await registerMedia(file);
    setIsUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSaveEdit = () => {
    if (!editingItem) return;
    // In strict mode, we only allow status updates from the UI unless we add a full PATCH endpoint for metadata
    updateMediaStatus(editingItem.id, editingItem.status);
    setEditingItem(null);
  };

  const toggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setFavorites(prev => {
        const next = new Set(prev);
        if (next.has(id)) {
            next.delete(id);
        } else {
            next.add(id);
        }
        localStorage.setItem('dhg_media_favorites', JSON.stringify(Array.from(next)));
        return next;
    });
  };

  // Helper to get a playable URL for the prototype
  const getPreviewUrl = (uri: string, type: string) => {
    if (uri.startsWith('http')) return uri;
    if (type.includes('video')) {
        return 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
    }
    if (type.includes('audio')) {
        return 'https://actions.google.com/sounds/v1/ambiences/coffee_shop.ogg'; 
    }
    return '';
  };

  // Derive the displayed list based on filter and sort
  const getProcessedItems = () => {
    let items = [...mediaItems];

    // Filter
    if (filterStatus !== 'ALL') {
      items = items.filter(item => item.status === filterStatus);
    }

    // Sort
    items.sort((a, b) => {
      switch (sortBy) {
        case 'DATE_NEW': return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        case 'DATE_OLD': return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
        case 'STATUS': return a.status.localeCompare(b.status);
        case 'TYPE': return a.source_type.localeCompare(b.source_type);
        default: return 0;
      }
    });

    return items;
  };

  const processedItems = getProcessedItems();

  return (
    <div className="space-y-6 font-sans pb-10 relative">
      <div className="flex justify-between items-end mb-4">
        <div>
          <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">Media Registry</h2>
          <p className="text-gray-500 text-base font-medium mt-1">Ingest and process content</p>
        </div>
        <div>
            <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} accept="audio/*,video/*" />
            <button 
                onClick={handleUploadClick}
                disabled={isUploading}
                className="bg-[#FF5500] hover:bg-[#e64d00] text-white px-5 py-2.5 rounded-full text-sm font-bold flex items-center gap-2 transition-all shadow-lg shadow-orange-500/20 active:scale-95"
            >
                {isUploading ? <BrandLogo size={16} animate /> : <Upload size={16} />}
                Ingest New
            </button>
        </div>
      </div>

      {/* Toolbar: Filter & Sort */}
      <div className="flex flex-wrap gap-3 mb-6">
        <div className="relative group">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                <Filter size={14} className="text-gray-500" />
            </div>
            <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="pl-9 pr-8 py-2 bg-white/50 border border-white/60 rounded-xl text-xs font-bold text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#FF5500]/20 appearance-none cursor-pointer hover:bg-white/80 transition-colors shadow-sm"
            >
                <option value="ALL">All Status</option>
                <option value={MediaStatus.COMPLETED}>Completed</option>
                <option value={MediaStatus.PROCESSING}>Processing</option>
                <option value={MediaStatus.PENDING}>Pending</option>
                <option value={MediaStatus.FAILED}>Failed</option>
            </select>
            <div className="absolute inset-y-0 right-2 flex items-center pointer-events-none">
                <ChevronRight size={14} className="text-gray-400 rotate-90" />
            </div>
        </div>

        <div className="relative group">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                <ArrowUpDown size={14} className="text-gray-500" />
            </div>
            <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="pl-9 pr-8 py-2 bg-white/50 border border-white/60 rounded-xl text-xs font-bold text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#FF5500]/20 appearance-none cursor-pointer hover:bg-white/80 transition-colors shadow-sm"
            >
                <option value="DATE_NEW">Newest First</option>
                <option value="DATE_OLD">Oldest First</option>
                <option value="STATUS">Status</option>
                <option value="TYPE">Type</option>
            </select>
            <div className="absolute inset-y-0 right-2 flex items-center pointer-events-none">
                <ChevronRight size={14} className="text-gray-400 rotate-90" />
            </div>
        </div>
      </div>

      <div className="glass-card rounded-[2rem] overflow-hidden shadow-sm min-h-[300px]">
        {processedItems.length > 0 ? (
            <div className="divide-y divide-gray-200/50">
            {processedItems.map((item) => (
                <div 
                    key={item.id} 
                    onClick={() => setEditingItem(item)}
                    className="group p-5 hover:bg-white/60 transition-colors cursor-pointer flex items-center justify-between"
                >
                    <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm ${
                            item.source_type.includes('video') 
                            ? 'bg-gradient-to-br from-pink-100 to-rose-100 text-pink-500' 
                            : 'bg-gradient-to-br from-cyan-100 to-blue-100 text-cyan-500'
                        }`}>
                            {item.source_type.includes('video') ? <FileVideo size={20} fill="currentColor" fillOpacity={0.2}/> : <FileAudio size={20} fill="currentColor" fillOpacity={0.2}/>}
                        </div>
                        <div>
                            <div className="font-bold text-gray-900 text-sm truncate max-w-[140px] sm:max-w-[200px]">{item.uri.split('/').pop()}</div>
                            <div className="text-[11px] text-gray-400 font-mono mt-0.5 tracking-wide">{item.id}</div>
                        </div>
                    </div>

                    <div className="flex items-center gap-4 sm:gap-6">
                        
                        <button 
                            onClick={(e) => toggleFavorite(e, item.id)}
                            className={`p-2 rounded-full transition-all hover:scale-105 active:scale-95 ${
                                favorites.has(item.id) 
                                ? 'text-amber-400 bg-amber-50' 
                                : 'text-gray-300 hover:text-amber-400 hover:bg-gray-100'
                            }`}
                            title={favorites.has(item.id) ? "Remove from favorites" : "Save to favorites"}
                        >
                            <Star size={18} fill={favorites.has(item.id) ? "currentColor" : "none"} />
                        </button>

                        <div className="text-right hidden sm:block">
                            <div className="text-xs font-semibold text-gray-500 flex items-center justify-end gap-1">
                                <Clock size={12}/> {item.duration_seconds > 0 ? `${Math.floor(item.duration_seconds / 60)}m ${item.duration_seconds % 60}s` : '--'}
                            </div>
                            <div className="text-[10px] text-gray-400 font-medium mt-0.5">{new Date(item.created_at).toLocaleDateString()}</div>
                        </div>

                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            item.status === MediaStatus.COMPLETED ? 'bg-emerald-100 text-emerald-600' :
                            item.status === MediaStatus.PROCESSING ? 'bg-blue-100 text-blue-600' :
                            item.status === MediaStatus.FAILED ? 'bg-red-100 text-red-600' :
                            'bg-gray-100 text-gray-400'
                        }`}>
                            {item.status === MediaStatus.COMPLETED && <CheckCircle size={16} />}
                            {item.status === MediaStatus.PROCESSING && <BrandLogo size={16} animate className="border-none bg-transparent" />}
                            {item.status === MediaStatus.FAILED && <XCircle size={16} />}
                            {item.status === MediaStatus.PENDING && <AlertTriangle size={16} />}
                        </div>
                        
                        <div className="w-8 h-8 rounded-full flex items-center justify-center bg-gray-5 text-gray-300 group-hover:bg-[#FF5500] group-hover:text-white transition-all shadow-sm">
                            <PlayCircle size={18} fill="currentColor" fillOpacity={0.2} />
                        </div>
                    </div>
                </div>
            ))}
            </div>
        ) : (
            <div className="flex flex-col items-center justify-center h-[300px] text-gray-400">
                <Filter size={32} className="mb-3 opacity-30" />
                <p className="text-sm font-medium">No media found matching criteria</p>
            </div>
        )}
      </div>

      {/* --- EDIT / PREVIEW MODAL --- */}
      {editingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <div 
                className="absolute inset-0 bg-white/40 backdrop-blur-md transition-opacity" 
                onClick={() => setEditingItem(null)}
            ></div>
            
            {/* Modal Card */}
            <div className={`relative w-full ${editingItem.source_type.startsWith('video') ? 'max-w-3xl' : 'max-w-md'} bg-white/90 backdrop-blur-2xl border border-white/60 shadow-2xl rounded-[2.5rem] p-8 animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]`}>
                
                {/* Modal Header & Close */}
                <div className="flex items-center justify-between mb-6 shrink-0">
                    <div>
                        <h3 className="text-xl font-bold text-gray-900 tracking-tight">Media Inspector</h3>
                        <p className="text-xs text-gray-500 font-medium">Preview and edit properties</p>
                    </div>
                    <button 
                        onClick={() => setEditingItem(null)}
                        className="p-2.5 bg-gray-100 rounded-full text-gray-500 hover:bg-gray-200 transition-colors hover:text-gray-900"
                    >
                        <X size={20} />
                    </button>
                </div>

                <div className="overflow-y-auto custom-scrollbar -mx-4 px-4">
                    {/* Media Preview Player */}
                    {(editingItem.source_type.startsWith('video') || editingItem.source_type.startsWith('audio')) && (
                        <div className="mb-8 rounded-3xl overflow-hidden bg-black shadow-lg ring-4 ring-white/50">
                            {editingItem.source_type.startsWith('video') ? (
                            <video 
                                src={getPreviewUrl(editingItem.uri, editingItem.source_type)} 
                                controls 
                                className="w-full aspect-video object-cover bg-black" 
                                poster="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop"
                            />
                            ) : (
                            <div className="p-8 flex flex-col items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
                                <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center text-[#FF5500] mb-6 shadow-xl shadow-orange-500/10 animate-pulse">
                                    <FileAudio size={40} />
                                </div>
                                <audio 
                                    src={getPreviewUrl(editingItem.uri, editingItem.source_type)} 
                                    controls 
                                    className="w-full" 
                                />
                            </div>
                            )}
                            <div className="px-4 py-2 bg-gray-900/90 backdrop-blur-sm flex items-center justify-between border-t border-white/10">
                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                    {editingItem.uri.startsWith('s3://') ? 'Previewing Proxy Asset' : 'Direct Source'}
                                </span>
                                {editingItem.duration_seconds > 0 && (
                                    <span className="text-[10px] font-mono text-gray-400">
                                        {Math.floor(editingItem.duration_seconds / 60)}:{String(editingItem.duration_seconds % 60).padStart(2, '0')}
                                    </span>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Edit Form */}
                    <div className="space-y-5 pb-2">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">ID</label>
                            <div className="w-full p-4 bg-gray-50/50 rounded-2xl text-xs font-mono text-gray-500 border border-transparent">
                                {editingItem.id}
                            </div>
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">URI Path</label>
                            <input 
                                type="text" 
                                disabled
                                value={editingItem.uri}
                                className="w-full p-4 bg-white/60 rounded-2xl text-sm font-semibold text-gray-500 border border-gray-200 cursor-not-allowed"
                            />
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Status</label>
                            <div className="relative">
                                <select 
                                    value={editingItem.status}
                                    onChange={(e) => setEditingItem({...editingItem, status: e.target.value as MediaStatus})}
                                    className="w-full p-4 bg-white/60 rounded-2xl text-sm font-bold text-gray-800 border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF5500]/20 focus:border-[#FF5500]/50 transition-all appearance-none shadow-sm cursor-pointer"
                                >
                                    <option value={MediaStatus.PENDING}>PENDING</option>
                                    <option value={MediaStatus.PROCESSING}>PROCESSING</option>
                                    <option value={MediaStatus.COMPLETED}>COMPLETED</option>
                                    <option value={MediaStatus.FAILED}>FAILED</option>
                                </select>
                                <ChevronRight className="absolute right-4 top-4 text-gray-400 rotate-90 pointer-events-none" size={20} />
                            </div>
                        </div>

                        <div className="pt-6">
                            <button 
                                onClick={handleSaveEdit}
                                className="w-full py-4 bg-[#FF5500] hover:bg-[#e64d00] text-white rounded-2xl font-bold text-base shadow-xl shadow-orange-500/20 active:scale-95 transition-all flex items-center justify-center gap-2 transform"
                            >
                                <Save size={20} />
                                Save Status Changes
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
