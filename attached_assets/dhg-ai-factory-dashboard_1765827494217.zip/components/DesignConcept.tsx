import React, { useState, useEffect } from 'react';
import { Sparkles, Maximize2, Layers, Download, RefreshCw, PenTool, Image as ImageIcon, X, CheckCircle2 } from 'lucide-react';
import { generateDesignMockup } from '../services/geminiService';
import { BrandLogo } from './BrandLogo';
import { DesignSettings } from '../types';

// --- TYPES ---
interface GeneratedImage {
  id: string;
  url: string;
  style: string;
  timestamp: number;
  ratio: string;
  prompt: string;
}

interface DesignConceptProps {
    settings: DesignSettings;
}

const IDEATION_PILLS = [
    "Futuristic HUD",
    "Clean Minimalist",
    "Dark Mode",
    "Neon Glow",
    "Data Dense",
    "Soft Gradients",
    "Isometric View",
    "High Contrast",
    "Glass Effects",
    "Brutalist Type"
];

export const DesignConcept: React.FC<DesignConceptProps> = ({ settings }) => {
  // Data State
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [remixingId, setRemixingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // UI State
  const [fullScreenImage, setFullScreenImage] = useState<GeneratedImage | null>(null);
  const [showReport, setShowReport] = useState(false);
  const [reportData, setReportData] = useState<{count: number, style: string, time: string} | null>(null);

  // Prompt is still local as it's the primary input action
  const [customPrompt, setCustomPrompt] = useState('');

  // Auto-hide report after delay
  useEffect(() => {
    if (showReport) {
        const timer = setTimeout(() => setShowReport(false), 5000);
        return () => clearTimeout(timer);
    }
  }, [showReport]);

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);
    setImages([]); 
    setShowReport(false);
    const startTime = Date.now();

    try {
      const promises = Array.from({ length: settings.imageCount }).map((_, index) => 
        generateDesignMockup(
          Date.now() + index,
          settings.themeMode, 
          settings.innovationLevel, 
          settings.selectedStyle, 
          settings.interfaceType, 
          settings.aspectRatio,
          customPrompt,
          settings.selectedPalette
        )
      );

      const results = await Promise.all(promises);
      
      const newImages: GeneratedImage[] = results
        .filter((url): url is string => url !== null)
        .map(url => ({
            id: crypto.randomUUID(),
            url,
            style: settings.selectedStyle,
            ratio: settings.aspectRatio,
            prompt: customPrompt,
            timestamp: Date.now()
        }));

      if (newImages.length > 0) {
        setImages(newImages);
        setReportData({
            count: newImages.length,
            style: settings.selectedStyle,
            time: ((Date.now() - startTime) / 1000).toFixed(1)
        });
        setShowReport(true);
      } else {
        setError("The Design Engine could not render visual data. Please try again.");
      }
    } catch (err) {
      setError("Connection to Design Engine failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleRemix = async (targetId: string) => {
    setRemixingId(targetId);
    try {
      const result = await generateDesignMockup(
          Date.now() + Math.random(), 
          settings.themeMode, 
          settings.innovationLevel, 
          settings.selectedStyle, 
          settings.interfaceType, 
          settings.aspectRatio,
          customPrompt,
          settings.selectedPalette
      );

      if (result) {
        const newImg: GeneratedImage = {
            id: crypto.randomUUID(),
            url: result,
            style: settings.selectedStyle,
            ratio: settings.aspectRatio,
            prompt: customPrompt,
            timestamp: Date.now()
        };
        // Prepend the remix to the list
        setImages(prev => [newImg, ...prev]);
      }
    } catch (err) {
      console.error("Remix failed", err);
    } finally {
      setRemixingId(null);
    }
  };

  const handleDownload = (imageUrl: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `dhg-concept-${settings.selectedStyle}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAddPill = (tag: string) => {
    setCustomPrompt(prev => {
        const trimmed = prev.trim();
        return trimmed ? `${trimmed}, ${tag}` : tag;
    });
  };

  return (
    <div className="h-full flex flex-col font-sans text-gray-800 relative overflow-hidden">
      
      {/* Main Studio View */}
      <div className="h-full flex flex-col">
        
        {/* Header Section */}
        <div className="mb-6 px-2 flex items-center justify-between shrink-0">
            <div>
                <h2 className="text-3xl font-extrabold tracking-tight text-gray-900 flex items-center gap-3">
                <span className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-purple-500/30">
                    <Layers size={20} />
                </span>
                Design Studio
                </h2>
                <p className="text-gray-500 text-sm font-medium mt-2 ml-1">Generate high-fidelity UI concepts with Gemini.</p>
            </div>
        </div>

        {/* Input Area */}
        <div className="bg-white border border-gray-200 p-2 rounded-[2rem] shadow-sm mb-8 mx-1 shrink-0 group focus-within:ring-2 focus-within:ring-[#FF5500]/20 transition-all">
             <div className="relative">
                <div className="absolute top-4 left-4 text-gray-400 pointer-events-none">
                    <PenTool size={16} />
                </div>
                <textarea 
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    placeholder={`Describe your vision for a ${settings.selectedStyle} ${settings.interfaceType}...`}
                    className="w-full bg-white rounded-t-[1.5rem] rounded-b-xl pl-12 pr-4 py-3.5 text-base font-medium text-gray-800 placeholder-gray-400 focus:outline-none resize-none h-24 transition-all"
                />
                
                {/* Ideation Pills */}
                <div className="px-4 pb-3 flex flex-wrap gap-2">
                    {IDEATION_PILLS.map((pill) => (
                        <button
                            key={pill}
                            onClick={() => handleAddPill(pill)}
                            className="px-2.5 py-1 bg-gray-50 hover:bg-indigo-50 text-gray-500 hover:text-indigo-600 border border-gray-200 hover:border-indigo-100 rounded-md text-[10px] font-bold uppercase tracking-wider transition-colors"
                        >
                            + {pill}
                        </button>
                    ))}
                </div>

                {/* Action Bar inside the input container */}
                <div className="flex items-center justify-between px-2 pb-2 pt-2 border-t border-gray-100 mt-1">
                    <div className="flex items-center gap-2 pl-2">
                         <div className="flex items-center gap-1.5 px-2 py-1 bg-gray-100 rounded-lg text-[10px] font-bold text-gray-500 uppercase tracking-wide">
                            <ImageIcon size={10} /> {settings.imageCount} Comps
                         </div>
                         <div className="flex items-center gap-1.5 px-2 py-1 bg-gray-100 rounded-lg text-[10px] font-bold text-gray-500 uppercase tracking-wide">
                            {settings.selectedStyle}
                         </div>
                    </div>
                    <button 
                        onClick={handleGenerate}
                        disabled={loading}
                        className="bg-[#FF5500] hover:bg-[#e64d00] text-white px-6 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-orange-500/20 active:scale-95 disabled:opacity-70 disabled:active:scale-100"
                    >
                        {loading ? <BrandLogo size={16} animate className="border-none bg-transparent" /> : <Sparkles size={16} fill="currentColor" />}
                        {loading ? 'Rendering...' : 'Generate'}
                    </button>
                </div>
             </div>
        </div>

        {/* Results Grid */}
        <div className="flex-1 min-h-0 overflow-y-auto no-scrollbar pb-24 px-1">
            {error && (
                <div className="p-4 bg-red-50 text-red-600 rounded-xl text-sm font-medium border border-red-100 mb-4 animate-in slide-in-from-top-2">
                    {error}
                </div>
            )}

            {images.length === 0 && !loading && !error && (
                <div className="h-full flex flex-col items-center justify-center text-gray-400 border-2 border-dashed border-gray-300/50 rounded-3xl bg-white/40 backdrop-blur-sm min-h-[300px]">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                         <Layers size={24} className="opacity-50" />
                    </div>
                    <p className="text-sm font-bold text-gray-500">Ready to Dream</p>
                    <p className="text-xs text-gray-400 mt-1">Settings are available in the sidebar menu.</p>
                </div>
            )}

            <div className={`grid gap-6 ${settings.imageCount === 1 ? 'grid-cols-1' : 'grid-cols-1 md:grid-cols-2'}`}>
                {images.map((img) => (
                    <div 
                        key={img.id} 
                        style={{ aspectRatio: img.ratio.replace(':', '/') }}
                        className="group relative rounded-3xl overflow-hidden shadow-2xl shadow-black/10 border border-white/50 bg-gray-100 animate-in zoom-in-95 duration-500"
                    >
                        <img 
                            src={img.url} 
                            alt="Generated Concept" 
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                        />
                        
                        {/* Overlay Actions */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-5">
                            <div className="flex items-center justify-between">
                                <span className="px-2.5 py-1 bg-white/20 backdrop-blur-md text-white text-[10px] font-bold uppercase rounded-full tracking-wider border border-white/20">
                                    {img.style}
                                </span>
                                <div className="flex gap-2">
                                    <button 
                                        onClick={() => handleRemix(img.id)}
                                        disabled={remixingId === img.id}
                                        className={`p-2.5 bg-white text-gray-900 rounded-full shadow-lg hover:scale-110 transition-transform ${remixingId === img.id ? 'animate-spin' : ''}`}
                                        title="Remix this concept"
                                    >
                                        <RefreshCw size={16} />
                                    </button>
                                    <button 
                                        onClick={() => handleDownload(img.url)}
                                        className="p-2.5 bg-white text-gray-900 rounded-full shadow-lg hover:scale-110 transition-transform"
                                        title="Download Image"
                                    >
                                        <Download size={16} />
                                    </button>
                                    <button 
                                        onClick={() => setFullScreenImage(img)}
                                        className="p-2.5 bg-white text-gray-900 rounded-full shadow-lg hover:scale-110 transition-transform"
                                        title="View Fullscreen"
                                    >
                                        <Maximize2 size={16} />
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        {/* Loading Overlay for Remix */}
                        {remixingId === img.id && (
                             <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-10">
                                <BrandLogo size={32} animate />
                             </div>
                        )}
                    </div>
                ))}
                
                {/* Skeleton Loaders with dynamic ratio */}
                {loading && Array.from({ length: settings.imageCount }).map((_, i) => (
                    <div 
                        key={i} 
                        style={{ aspectRatio: settings.aspectRatio.replace(':', '/') }}
                        className="rounded-3xl bg-white/60 backdrop-blur-md animate-pulse flex items-center justify-center border border-white/60 shadow-sm"
                    >
                        <div className="flex flex-col items-center gap-3">
                            <BrandLogo size={24} animate />
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Rendering...</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>

        {/* --- LIGHTBOX MODAL --- */}
        {fullScreenImage && (
            <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 md:p-10 animate-in fade-in duration-200">
                <button 
                    onClick={() => setFullScreenImage(null)}
                    className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors z-20"
                >
                    <X size={24} />
                </button>
                
                <img 
                    src={fullScreenImage.url} 
                    alt="Fullscreen Concept" 
                    className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" 
                />

                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 px-6 py-3 bg-black/50 backdrop-blur-md text-white rounded-full text-sm font-medium border border-white/10 flex items-center gap-4">
                     <span>{fullScreenImage.style}</span>
                     <span className="w-1 h-1 rounded-full bg-white/50"></span>
                     <span>{fullScreenImage.ratio}</span>
                     <button onClick={() => handleDownload(fullScreenImage.url)} className="ml-2 text-indigo-400 hover:text-indigo-300 font-bold">Download</button>
                </div>
            </div>
        )}

        {/* --- GENERATION REPORT SLIDE-UP --- */}
        <div 
            className={`fixed bottom-6 right-6 md:right-10 z-40 max-w-sm w-full bg-gray-900/90 backdrop-blur-xl text-white p-5 rounded-2xl shadow-2xl border border-white/10 transform transition-all duration-500 cubic-bezier(0.16, 1, 0.3, 1) ${showReport ? 'translate-y-0 opacity-100' : 'translate-y-[120%] opacity-0'}`}
        >
            <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2 text-emerald-400">
                    <CheckCircle2 size={18} />
                    <span className="text-xs font-bold uppercase tracking-widest">Generation Complete</span>
                </div>
                <button onClick={() => setShowReport(false)} className="text-gray-500 hover:text-white transition-colors">
                    <X size={16} />
                </button>
            </div>
            
            {reportData && (
                <div className="space-y-3">
                    <p className="text-sm text-gray-200 leading-relaxed">
                        Successfully rendered <strong className="text-white">{reportData.count} concepts</strong> using the <strong className="text-white">{reportData.style}</strong> engine.
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                            <span className="block text-gray-500 mb-0.5">Render Time</span>
                            <span className="font-mono text-emerald-400">{reportData.time}s</span>
                        </div>
                        <div className="bg-white/5 p-2 rounded-lg border border-white/5">
                            <span className="block text-gray-500 mb-0.5">Innovation</span>
                            <span className="font-mono text-orange-400">{settings.innovationLevel}%</span>
                        </div>
                    </div>
                </div>
            )}
        </div>

      </div>
    </div>
  );
};