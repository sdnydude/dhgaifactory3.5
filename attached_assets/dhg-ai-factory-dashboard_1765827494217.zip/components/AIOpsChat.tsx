import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { Sparkles, Paperclip, BarChart3, Database, Palette, RefreshCw, StopCircle, ArrowUp, BrainCircuit } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage, ViewType } from '../types';
import { generateOpsInsight } from '../services/geminiService';

export interface AIOpsChatRef {
  sendMessage: (text: string) => void;
}

interface AIOpsChatProps {
    onShowArtifact: (type: ViewType) => void;
    activeArtifact: ViewType;
    initialMessages?: ChatMessage[];
}

export const AIOpsChat = forwardRef<AIOpsChatRef, AIOpsChatProps>(({ onShowArtifact, activeArtifact, initialMessages }, ref) => {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages || [
    {
      id: 'welcome',
      role: 'model',
      text: "I'm connected to Factory 7. Checking systems... All nominally healthy.",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // New state for thinking animation
  const [thinkingStep, setThinkingStep] = useState<string>('');
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading, thinkingStep]);

  const handleSend = async (text: string = input) => {
    if (!text.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: text,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);
    setThinkingStep('Analyzing intent...');

    // Simulate thinking steps for UI effect
    const thinkTimer1 = setTimeout(() => setThinkingStep('Querying system metrics...'), 800);
    const thinkTimer2 = setTimeout(() => setThinkingStep('Formulating response...'), 1800);

    // Simple intent detection for view switching
    if (text.toLowerCase().includes('health') || text.toLowerCase().includes('status')) {
        onShowArtifact('DASHBOARD');
    } else if (text.toLowerCase().includes('media') || text.toLowerCase().includes('registry')) {
        onShowArtifact('MEDIA');
    } else if (text.toLowerCase().includes('design') || text.toLowerCase().includes('studio')) {
        onShowArtifact('DESIGN');
    }

    try {
        const responseText = await generateOpsInsight(text);
        
        clearTimeout(thinkTimer1);
        clearTimeout(thinkTimer2);

        const botMsg: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: 'model',
            text: responseText,
            timestamp: new Date()
        };
        setMessages(prev => [...prev, botMsg]);
    } catch (e) {
        setMessages(prev => [...prev, {
            id: Date.now().toString(),
            role: 'model',
            text: "I lost connection to the neural core.",
            timestamp: new Date()
        }]);
    } finally {
        setIsLoading(false);
        setThinkingStep('');
    }
  };

  useImperativeHandle(ref, () => ({
    sendMessage: (text: string) => {
        handleSend(text);
    }
  }));

  const getAdaptiveActions = () => {
    if (activeArtifact === 'DASHBOARD') {
        return [
            { label: 'Refresh', icon: <RefreshCw size={13} />, action: () => handleSend('Refresh metrics') },
            { label: 'Alerts', icon: <StopCircle size={13} />, action: () => handleSend('Show critical alerts') },
        ];
    }
    if (activeArtifact === 'MEDIA') {
        return [
            { label: 'Ingest', icon: <Paperclip size={13} />, action: () => handleSend('Ingest new file') },
            { label: 'Jobs', icon: <RefreshCw size={13} />, action: () => handleSend('Check pending jobs') },
        ];
    }
    return [
        { label: 'Metrics', icon: <BarChart3 size={13} />, action: () => { onShowArtifact('DASHBOARD'); handleSend('Show metrics'); } },
        { label: 'Registry', icon: <Database size={13} />, action: () => { onShowArtifact('MEDIA'); handleSend('Open registry'); } },
        { label: 'Studio', icon: <Palette size={13} />, action: () => { onShowArtifact('DESIGN'); handleSend('Open Design Studio'); } },
    ];
  };

  return (
    <div className="flex flex-col h-full relative font-sans">
      
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar" ref={scrollRef}>
        
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className="max-w-[90%]">
               {msg.role === 'model' && (
                  <div className="flex items-center gap-2 mb-1 ml-1">
                      <span className="text-[10px] font-bold text-[#8A8886] uppercase tracking-widest">Digital Harmony</span>
                  </div>
               )}

               <div className={`px-4 py-3 text-[14px] leading-relaxed break-words shadow-sm markdown-content ${
                 msg.role === 'user' 
                   ? 'bg-[#E6DCC8]/90 backdrop-blur-md text-[#3A3836] rounded-2xl rounded-br-sm border border-white/40' 
                   : 'bg-white/60 backdrop-blur-md border border-white/60 text-[#3A3836] rounded-2xl rounded-tl-sm'
               }`}>
                    <ReactMarkdown 
                        components={{
                            p: ({children}) => <p className="mb-2 last:mb-0">{children}</p>,
                            ul: ({children}) => <ul className="list-disc pl-4 mb-2 space-y-1 marker:text-[#8A8886]">{children}</ul>,
                            ol: ({children}) => <ol className="list-decimal pl-4 mb-2 space-y-1 marker:text-[#8A8886]">{children}</ol>,
                            li: ({children}) => <li className="pl-1">{children}</li>,
                            h1: ({children}) => <h1 className="text-base font-bold mb-2 mt-3">{children}</h1>,
                            h2: ({children}) => <h2 className="text-sm font-bold mb-2 mt-2">{children}</h2>,
                            h3: ({children}) => <h3 className="text-xs font-bold mb-1 mt-2 uppercase text-gray-500">{children}</h3>,
                            a: ({href, children}) => <a href={href} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{children}</a>,
                            pre: ({children}) => <pre className="bg-black/5 p-3 rounded-xl overflow-x-auto my-2 border border-black/5 text-xs font-mono custom-scrollbar">{children}</pre>,
                            code: ({children, className}) => <code className={className}>{children}</code>
                        }}
                    >
                        {msg.text}
                    </ReactMarkdown>
               </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start w-full">
             <div className="bg-white/40 border border-white/50 rounded-2xl rounded-tl-sm p-4 w-full max-w-[85%] shadow-sm backdrop-blur-sm relative overflow-hidden">
                {/* Thinking Header */}
                <div className="flex items-center gap-2 mb-2 text-[#D4A373]">
                    <BrainCircuit size={16} className="animate-pulse" />
                    <span className="text-xs font-bold uppercase tracking-widest">Thinking</span>
                </div>
                
                {/* Animated Thinking Stream */}
                <div className="space-y-1">
                    <div className="h-1 w-full bg-gray-200/50 rounded-full overflow-hidden">
                        <div className="h-full bg-[#D4A373]/50 animate-progress-indeterminate"></div>
                    </div>
                    <p className="text-xs text-gray-500 font-mono mt-2 animate-pulse">{thinkingStep}</p>
                </div>
             </div>
          </div>
        )}
        <div className="h-32"></div>
      </div>

      {/* --- FLOATING INPUT CAPSULE --- */}
      <div className="absolute bottom-4 left-0 right-0 px-4 flex justify-center z-20">
        <div className="w-full flex flex-col gap-2">
            
            {/* Quick Actions */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar mask-linear-fade">
                {getAdaptiveActions().map((action, idx) => (
                    <button 
                        key={idx}
                        onClick={action.action}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-white/40 hover:bg-white/60 backdrop-blur-md border border-white/50 rounded-full text-[11px] font-bold text-[#5A5856] shadow-sm transition-colors whitespace-nowrap active:scale-95 shrink-0"
                    >
                        {action.icon}
                        {action.label}
                    </button>
                ))}
            </div>

            {/* Input Bar - Double Glazed Effect */}
            <div className="bg-white/50 backdrop-blur-xl rounded-[24px] shadow-lg shadow-black/5 border border-white/60 flex items-center p-1.5 transition-all ring-1 ring-white/40 focus-within:bg-white/70 focus-within:ring-white/60">
                <button className="p-2 text-[#8A8886] hover:text-[#5A5856] transition-colors rounded-full hover:bg-white/20">
                     <Paperclip size={18} />
                </button>
                
                <input
                    className="flex-1 bg-transparent text-[#3A3836] placeholder-[#8A8886]/70 px-2 py-2 text-[14px] font-medium focus:outline-none min-w-0"
                    placeholder="Ask Digital Harmony..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSend();
                    }}
                />
                
                <button 
                    onClick={() => handleSend()}
                    disabled={!input.trim()}
                    className={`p-2 rounded-full transition-all duration-300 shrink-0 ${
                        input.trim() 
                        ? 'bg-[#3A3836] text-white shadow-md' 
                        : 'bg-white/10 text-[#D4D4D4]'
                    }`}
                >
                    <ArrowUp size={18} strokeWidth={3} />
                </button>
            </div>
            
        </div>
      </div>
      
      {/* Animation & Markdown Styles */}
      <style>{`
        @keyframes progress-indeterminate {
            0% { width: 0%; margin-left: 0%; }
            50% { width: 70%; margin-left: 30%; }
            100% { width: 0%; margin-left: 100%; }
        }
        .animate-progress-indeterminate {
            animation: progress-indeterminate 1.5s infinite ease-in-out;
        }

        /* Markdown Styles */
        .markdown-content strong {
            font-weight: 700;
            color: #111;
        }
        
        /* Inline Code */
        .markdown-content code {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            background: rgba(0, 0, 0, 0.06);
            padding: 2px 5px;
            border-radius: 4px;
            font-size: 0.9em;
            color: #d946ef; /* Fuchsia-500/600 feel */
        }

        /* Block Code Override: Reset inline style if inside pre */
        .markdown-content pre code {
            background: transparent;
            padding: 0;
            border-radius: 0;
            color: inherit;
            font-size: inherit;
        }
      `}</style>
    </div>
  );
});
