import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, Pause, Activity, Database, ChevronRight, X, 
  Plus, Trash2, 
  Circle, Square, Upload,
  Cpu, Waves, MoveHorizontal, SkipBack, Rewind, FastForward, Music
} from 'lucide-react';
import { AudioSettings, MediaItem } from '../types';
import { MOCK_MEDIA } from '../services/mockData';

interface AudioStudioProps {
    settings?: AudioSettings;
}

// --- Plugin State Interfaces ---
interface CleanupState { enabled: boolean; reduction: number; }
interface PreAmpState { enabled: boolean; gain: number; }
interface EQState { enabled: boolean; lowGain: number; lowFreq: number; highGain: number; highFreq: number; }
interface CompressorState { enabled: boolean; threshold: number; ratio: number; attack: number; release: number; }
interface DelayState { enabled: boolean; time: number; feedback: number; }
interface EchoState { enabled: boolean; time: number; decay: number; }
interface ReverbState { enabled: boolean; size: number; mix: number; }
interface MasterState { enabled: boolean; gain: number; }

// --- New AI Controller State ---
interface DigitalHarmonyState {
    enabled: boolean;
    model: string;
    intensity: number;
    analysisSpectrum: boolean;
    analysisVector: boolean;
}

interface DspState {
    cleanup: CleanupState;
    preamp: PreAmpState;
    eq: EQState;
    compressor: CompressorState;
    delay: DelayState;
    echo: EchoState;
    reverb: ReverbState;
    master: MasterState;
}

// --- Track Interface ---
interface Track {
    id: string;
    name: string;
    volume: number; // 0 to 1.5
    pan: number;    // -1 to 1
    muted: boolean;
    solo: boolean;
    armed: boolean;
    buffer: AudioBuffer | null;
    peaks: number[];
    color: string;
    height: number;
}

const TRACK_COLORS = ['#FF5500', '#3B82F6', '#10B981', '#8B5CF6', '#EC4899', '#F59E0B'];

const DHGM_CATEGORIES = [
    { name: 'Dynamics', items: ['Compressor', 'Multiband Comp', 'Noise Gate', 'De-esser', 'Expander', 'Brickwall Limiter'] },
    { name: 'Equalization', items: ['Parametric EQ', 'Graphic EQ', 'Dynamic EQ', 'High Pass Filter', 'Notch Filter', 'Pultec-style EQ'] },
    { name: 'Restoration', items: ['De-noise', 'De-click', 'De-hum', 'Spectral Repair', 'De-clip', 'Phase Align'] },
    { name: 'Spatial', items: ['Convolution Reverb', 'Algo Reverb', 'Stereo Delay', 'Tape Echo', 'Chorus', 'Stereo Widener'] },
    { name: 'Metering', items: ['Loudness (LUFS)', 'True Peak', 'Phase Corr', 'Spectrogram', 'Goniometer', 'Stereo Scope'] }
];

// --- RACK MODULE COMPONENT (Compact) ---
interface RackModuleProps {
    label: string;
    color: string;
    enabled: boolean;
    onToggle: () => void;
    children: React.ReactNode;
}

const RackModule: React.FC<RackModuleProps> = ({ label, color, enabled, onToggle, children }) => {
    const bgStyle = enabled 
        ? `bg-gradient-to-b from-${color}-500 to-${color}-700 border-${color}-400`
        : 'bg-gradient-to-b from-gray-200 to-gray-300 border-gray-300';
    const textColor = enabled ? 'text-white' : 'text-gray-500';
    
    return (
        <div className={`
            relative shrink-0 w-24 h-40 rounded-lg border-2 shadow-xl flex flex-col items-center justify-between py-2 select-none
            transition-all duration-300 ${bgStyle}
        `}>
            {/* Screws */}
            <div className="absolute top-1 left-1 w-1 h-1 rounded-full bg-black/20"></div>
            <div className="absolute top-1 right-1 w-1 h-1 rounded-full bg-black/20"></div>
            <div className="absolute bottom-1 left-1 w-1 h-1 rounded-full bg-black/20"></div>
            <div className="absolute bottom-1 right-1 w-1 h-1 rounded-full bg-black/20"></div>

            <div className={`text-[9px] font-black uppercase tracking-tighter ${textColor} text-center px-0.5 truncate w-full`}>
                {label}
            </div>

            <div className="flex-1 w-full flex flex-col items-center justify-center gap-1 px-1.5">
                {children}
            </div>

            <button onClick={(e) => { e.stopPropagation(); onToggle(); }} className="relative group pb-1">
                <div className={`absolute -top-3 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full shadow-[0_0_6px_rgba(255,255,255,0.8)] transition-all ${enabled ? 'bg-red-500 animate-pulse' : 'bg-red-900/50'}`}></div>
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-gray-100 to-gray-400 border-2 border-gray-500 shadow-md active:scale-95 transition-transform flex items-center justify-center">
                    <div className="w-3 h-3 rounded-full border border-gray-400 bg-gray-200"></div>
                </div>
            </button>
        </div>
    );
};

// --- DIGITAL HARMONY RACK UNIT ---
const DigitalHarmonyRackUnit = ({ 
    state, 
    onChange 
}: { 
    state: DigitalHarmonyState, 
    onChange: (s: DigitalHarmonyState) => void 
}) => {
    return (
        <div className="relative w-full md:w-auto md:flex-1 h-auto md:h-48 bg-[#1a1a1a] rounded-lg border-2 border-[#333] shadow-2xl flex flex-col overflow-hidden group">
            
            {/* Rack Ears */}
            <div className="absolute left-0 top-0 bottom-0 w-4 bg-[#111] border-r border-[#333] flex flex-col justify-between py-2 items-center z-10">
                {[1,2,3,4].map(i => <div key={i} className="w-2 h-2 rounded-full bg-[#000] border border-[#444]"></div>)}
            </div>
            <div className="absolute right-0 top-0 bottom-0 w-4 bg-[#111] border-l border-[#333] flex flex-col justify-between py-2 items-center z-10">
                {[1,2,3,4].map(i => <div key={i} className="w-2 h-2 rounded-full bg-[#000] border border-[#444]"></div>)}
            </div>

            {/* Faceplate */}
            <div className="flex-1 mx-4 bg-gradient-to-b from-[#2a2a2a] to-[#1a1a1a] flex flex-col p-3 relative h-full">
                
                {/* Branding */}
                <div className="flex justify-between items-start mb-2 border-b border-white/5 pb-2 shrink-0">
                    <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded bg-black border border-gray-700 flex items-center justify-center relative overflow-hidden">
                            <div className={`absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-purple-500/20 ${state.enabled ? 'animate-pulse' : ''}`}></div>
                            <Cpu size={18} className={state.enabled ? "text-cyan-400" : "text-gray-600"} />
                        </div>
                        <div>
                            <h3 className="text-sm font-black text-gray-200 tracking-wider uppercase leading-none font-mono">Digital Harmony</h3>
                            <span className="text-[9px] text-cyan-500 font-mono tracking-[0.2em] uppercase">Neural Signal Processor</span>
                        </div>
                    </div>
                    <button 
                        onClick={() => onChange({...state, enabled: !state.enabled})}
                        className={`w-12 h-6 rounded-full p-1 transition-colors ${state.enabled ? 'bg-cyan-900/50 border border-cyan-500' : 'bg-gray-800 border border-gray-600'}`}
                    >
                        <div className={`w-4 h-4 rounded-full bg-white shadow-md transition-transform ${state.enabled ? 'translate-x-6 bg-cyan-100' : 'translate-x-0 bg-gray-400'}`}></div>
                    </button>
                </div>

                {/* Main Controls Grid */}
                <div className={`flex flex-1 gap-4 transition-opacity duration-300 min-h-0 ${state.enabled ? 'opacity-100' : 'opacity-40 grayscale pointer-events-none'}`}>
                    
                    {/* Bundle Selector - Fixed Layout Bug */}
                    <div className="flex-1 bg-black/80 rounded border border-gray-700 p-2 shadow-inner relative overflow-hidden flex flex-col min-h-0">
                         <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 pointer-events-none bg-[length:100%_4px,3px_100%]"></div>
                         <label className="text-[9px] text-gray-500 font-bold uppercase mb-1.5 z-20 block shrink-0 bg-black/80 pb-1 border-b border-gray-700">Active Bundle (DHGM MIX)</label>
                         
                         <div className="flex-1 overflow-y-auto custom-scrollbar z-20 pb-4">
                            {DHGM_CATEGORIES.map(cat => (
                                <div key={cat.name} className="mb-2">
                                    <div className="text-[8px] font-bold text-gray-600 uppercase mb-0.5 px-1">{cat.name}</div>
                                    <div className="space-y-0.5">
                                        {cat.items.map(item => {
                                            const id = `dhgm-${item.toLowerCase().replace(/\s+/g, '-')}`;
                                            return (
                                                <button
                                                    key={id}
                                                    onClick={() => onChange({...state, model: id})}
                                                    className={`w-full text-left text-[10px] font-mono px-2 py-0.5 rounded flex items-center justify-between ${state.model === id ? 'bg-white/10 text-cyan-300' : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'}`}
                                                >
                                                    <span className="truncate">{item}</span>
                                                    {state.model === id && <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full shadow-[0_0_5px_cyan] shrink-0"></div>}
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>
                            ))}
                         </div>
                    </div>

                    {/* Middle: Intensity Knob */}
                    <div className="flex flex-col items-center justify-center w-24 border-x border-white/5 px-2 shrink-0">
                         <div className="relative w-14 h-14 rounded-full bg-[#111] border-2 border-[#444] shadow-lg flex items-center justify-center mb-1 group cursor-pointer">
                            <div 
                                className="absolute top-0 left-1/2 w-1 h-1/2 bg-gray-600 origin-bottom transition-transform" 
                                style={{ transform: `translateX(-50%) rotate(${state.intensity * 270 - 135}deg)` }}
                            >
                                <div className="w-1 h-2 bg-white mt-1 rounded-full"></div>
                            </div>
                            <input 
                                type="range" min="0" max="1" step="0.01"
                                value={state.intensity}
                                onChange={(e) => onChange({...state, intensity: parseFloat(e.target.value)})}
                                className="absolute inset-0 opacity-0 cursor-pointer"
                            />
                         </div>
                         <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Dry / Wet</span>
                         <span className="text-[10px] font-mono text-cyan-400">{(state.intensity * 100).toFixed(0)}%</span>
                    </div>

                    {/* Right: Analysis Toggles */}
                    <div className="w-32 flex flex-col gap-2 justify-center shrink-0">
                        <label className="text-[9px] text-gray-500 font-bold uppercase text-center">Analysis Mode</label>
                        <button 
                            onClick={() => onChange({...state, analysisSpectrum: !state.analysisSpectrum})}
                            className={`flex items-center gap-2 px-2 py-1.5 rounded border text-[10px] font-bold uppercase transition-all ${state.analysisSpectrum ? 'bg-cyan-900/30 border-cyan-500 text-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.1)]' : 'bg-gray-800 border-gray-600 text-gray-500'}`}
                        >
                            <Waves size={12} />
                            <span>Spectral Flux</span>
                            <div className={`ml-auto w-1.5 h-1.5 rounded-full ${state.analysisSpectrum ? 'bg-cyan-400' : 'bg-gray-600'}`}></div>
                        </button>
                        <button 
                            onClick={() => onChange({...state, analysisVector: !state.analysisVector})}
                            className={`flex items-center gap-2 px-2 py-1.5 rounded border text-[10px] font-bold uppercase transition-all ${state.analysisVector ? 'bg-purple-900/30 border-purple-500 text-purple-400 shadow-[0_0_10px_rgba(168,85,247,0.1)]' : 'bg-gray-800 border-gray-600 text-gray-500'}`}
                        >
                            <MoveHorizontal size={12} />
                            <span>Vector Scope</span>
                            <div className={`ml-auto w-1.5 h-1.5 rounded-full ${state.analysisVector ? 'bg-purple-400' : 'bg-gray-600'}`}></div>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// Mini Slider
const RackSlider = ({ value, min, max, step, onChange, label, unit }: { value: number, min: number, max: number, step: number, onChange: (v: number) => void, label: string, unit?: string }) => (
    <div className="w-full space-y-0.5">
        <div className="flex justify-between text-[6px] font-bold text-white/80 uppercase tracking-wider">
            <span>{label}</span>
            <span>{Math.round(value)}{unit}</span>
        </div>
        <input 
            type="range" 
            min={min} max={max} step={step} 
            value={value}
            onChange={(e) => onChange(parseFloat(e.target.value))}
            className="w-full h-1 bg-black/30 rounded-full appearance-none accent-white cursor-pointer"
        />
    </div>
);


export const AudioStudio: React.FC<AudioStudioProps> = ({ settings }) => {
    // --- Master DSP State ---
    const [dsp, setDsp] = useState<DspState>({
        cleanup: { enabled: false, reduction: 0.5 },
        preamp: { enabled: true, gain: 1.0 },
        eq: { enabled: true, lowGain: 0, lowFreq: 250, highGain: 0, highFreq: 4000 },
        compressor: { enabled: true, threshold: -20, ratio: 4, attack: 0.003, release: 0.25 },
        delay: { enabled: false, time: 250, feedback: 0.3 },
        echo: { enabled: false, time: 150, decay: 0.5 },
        reverb: { enabled: false, size: 0.5, mix: 0.3 },
        master: { enabled: true, gain: 1.0 }
    });

    const [digitalHarmony, setDigitalHarmony] = useState<DigitalHarmonyState>({
        enabled: true,
        model: 'dhgm-compressor',
        intensity: 0.75,
        analysisSpectrum: true,
        analysisVector: false
    });

    const [tracks, setTracks] = useState<Track[]>([]);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isRecording, setIsRecording] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(30); 
    const [showRegistryPicker, setShowRegistryPicker] = useState(false);

    // --- Audio Engine Refs ---
    const audioContextRef = useRef<AudioContext | null>(null);
    const masterInputNodeRef = useRef<GainNode | null>(null);
    const trackNodesRef = useRef<Map<string, { gain: GainNode, pan: StereoPannerNode, source?: AudioBufferSourceNode }>>(new Map());
    
    // Nodes
    const cleanupHPRef = useRef<BiquadFilterNode | null>(null);
    const cleanupPeakRef = useRef<BiquadFilterNode | null>(null);
    const preampNodeRef = useRef<GainNode | null>(null);
    const lowShelfNodeRef = useRef<BiquadFilterNode | null>(null);
    const highShelfNodeRef = useRef<BiquadFilterNode | null>(null);
    const compressorNodeRef = useRef<DynamicsCompressorNode | null>(null);
    const delayNodeRef = useRef<DelayNode | null>(null);
    const delayFeedbackRef = useRef<GainNode | null>(null);
    const echoNodeRef = useRef<DelayNode | null>(null);
    const echoFeedbackRef = useRef<GainNode | null>(null);
    const reverbNodeRef = useRef<ConvolverNode | null>(null);
    const reverbMixRef = useRef<GainNode | null>(null);
    const limiterNodeRef = useRef<DynamicsCompressorNode | null>(null); // Brickwall Limiter
    const masterGainNodeRef = useRef<GainNode | null>(null);
    const analyzerRef = useRef<AnalyserNode | null>(null);

    // Loop & Recording
    const requestRef = useRef<number | undefined>(undefined);
    const startTimeRef = useRef<number>(0);
    const startOffsetRef = useRef<number>(0);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const recordedChunksRef = useRef<Blob[]>([]);
    const containerRef = useRef<HTMLDivElement>(null);

    // --- Reverb Impulse Generator ---
    const buildImpulse = (ctx: AudioContext, duration: number, decay: number) => {
        const rate = ctx.sampleRate;
        const length = rate * duration;
        const impulse = ctx.createBuffer(2, length, rate);
        const left = impulse.getChannelData(0);
        const right = impulse.getChannelData(1);
        for (let i = 0; i < length; i++) {
             const n = i / length;
             const e = Math.pow(1 - n, decay);
             left[i] = (Math.random() * 2 - 1) * e;
             right[i] = (Math.random() * 2 - 1) * e;
        }
        return impulse;
    };

    // --- Initialization ---
    useEffect(() => {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioContextClass();
        audioContextRef.current = ctx;

        // Create Nodes
        const masterInput = ctx.createGain();
        const cleanupHP = ctx.createBiquadFilter();
        const cleanupPeak = ctx.createBiquadFilter();
        const preamp = ctx.createGain();
        const lowShelf = ctx.createBiquadFilter();
        const highShelf = ctx.createBiquadFilter();
        const compressor = ctx.createDynamicsCompressor();
        
        // Delay Chain
        const delay = ctx.createDelay(2.0);
        const delayFeed = ctx.createGain();
        
        // Echo Chain
        const echo = ctx.createDelay(5.0);
        const echoFeed = ctx.createGain();
        
        // Reverb Chain
        const reverb = ctx.createConvolver();
        const reverbMix = ctx.createGain(); // Controls wet level
        
        // Master
        const limiter = ctx.createDynamicsCompressor();
        const masterGain = ctx.createGain();
        const analyzer = ctx.createAnalyser();

        // Node Configs
        cleanupHP.type = 'highpass';
        cleanupPeak.type = 'peaking';
        lowShelf.type = 'lowshelf';
        highShelf.type = 'highshelf';
        analyzer.fftSize = 256;
        
        // Limiter Config (Brickwall-ish)
        limiter.threshold.value = -0.5;
        limiter.knee.value = 0;
        limiter.ratio.value = 20; // High ratio for limiting
        limiter.attack.value = 0.001;
        limiter.release.value = 0.1;

        // Save Refs
        masterInputNodeRef.current = masterInput;
        cleanupHPRef.current = cleanupHP;
        cleanupPeakRef.current = cleanupPeak;
        preampNodeRef.current = preamp;
        lowShelfNodeRef.current = lowShelf;
        highShelfNodeRef.current = highShelf;
        compressorNodeRef.current = compressor;
        delayNodeRef.current = delay;
        delayFeedbackRef.current = delayFeed;
        echoNodeRef.current = echo;
        echoFeedbackRef.current = echoFeed;
        reverbNodeRef.current = reverb;
        reverbMixRef.current = reverbMix;
        limiterNodeRef.current = limiter;
        masterGainNodeRef.current = masterGain;
        analyzerRef.current = analyzer;

        // --- Wiring ---
        // 1. Basic Clean Chain
        masterInput.connect(cleanupHP);
        cleanupHP.connect(cleanupPeak);
        cleanupPeak.connect(preamp);
        preamp.connect(lowShelf);
        lowShelf.connect(highShelf);
        highShelf.connect(compressor);
        
        // 2. Parallel Effects or Series Insert? 
        // For simplicity, we'll do series inserts with internal wet/dry bypass logic logic handled in parameter update (gain staging).
        // Actually, WebAudio routing is static, we change gains.
        // Let's create a main trunk and sidechains.
        
        // Compressor -> Limiter (Main Trunk)
        compressor.connect(limiter);

        // Delay Sidechain (Add to Limiter input)
        compressor.connect(delay);
        delay.connect(delayFeed);
        delayFeed.connect(delay); // Feedback Loop
        delay.connect(limiter);

        // Echo Sidechain (Add to Limiter input)
        compressor.connect(echo);
        echo.connect(echoFeed);
        echoFeed.connect(echo); // Feedback Loop
        echo.connect(limiter);

        // Reverb Sidechain (Add to Limiter input)
        compressor.connect(reverb);
        reverb.connect(reverbMix);
        reverbMix.connect(limiter);

        // 3. Final Output
        limiter.connect(masterGain);
        masterGain.connect(analyzer);
        analyzer.connect(ctx.destination);

        // Init Tracks
        if (tracks.length === 0) {
            addNewTrack("Audio 1");
            addNewTrack("Audio 2");
            addNewTrack("Audio 3");
            addNewTrack("Audio 4");
        }

        return () => {
            ctx.close();
            if (requestRef.current) cancelAnimationFrame(requestRef.current);
        };
    }, []);

    // --- DSP Parameters ---
    useEffect(() => {
        if (!audioContextRef.current) return;
        const t = audioContextRef.current.currentTime;
        const ramp = 0.05;

        // Cleanup
        if (dsp.cleanup.enabled) {
            const hpFreq = 20 + (dsp.cleanup.reduction * 130);
            const peakGain = dsp.cleanup.reduction * 3;
            cleanupHPRef.current?.frequency.setTargetAtTime(hpFreq, t, ramp);
            cleanupHPRef.current?.Q.setTargetAtTime(0.7, t, ramp);
            cleanupPeakRef.current?.frequency.setTargetAtTime(3000, t, ramp);
            cleanupPeakRef.current?.gain.setTargetAtTime(peakGain, t, ramp);
        } else {
            cleanupHPRef.current?.frequency.setTargetAtTime(0, t, ramp);
            cleanupPeakRef.current?.gain.setTargetAtTime(0, t, ramp);
        }

        // Basic EQ/Comp
        preampNodeRef.current?.gain.setTargetAtTime(dsp.preamp.enabled ? dsp.preamp.gain : 1.0, t, ramp);
        lowShelfNodeRef.current?.gain.setTargetAtTime(dsp.eq.enabled ? dsp.eq.lowGain : 0, t, ramp);
        lowShelfNodeRef.current?.frequency.setTargetAtTime(dsp.eq.lowFreq, t, ramp);
        highShelfNodeRef.current?.gain.setTargetAtTime(dsp.eq.enabled ? dsp.eq.highGain : 0, t, ramp);
        highShelfNodeRef.current?.frequency.setTargetAtTime(dsp.eq.highFreq, t, ramp);

        if (dsp.compressor.enabled) {
            compressorNodeRef.current?.threshold.setTargetAtTime(dsp.compressor.threshold, t, ramp);
            compressorNodeRef.current?.ratio.setTargetAtTime(dsp.compressor.ratio, t, ramp);
        } else {
            compressorNodeRef.current?.threshold.setTargetAtTime(0, t, ramp);
            compressorNodeRef.current?.ratio.setTargetAtTime(1, t, ramp);
        }

        // Delay
        if (delayNodeRef.current && delayFeedbackRef.current) {
            if (dsp.delay.enabled) {
                delayNodeRef.current.delayTime.setTargetAtTime(dsp.delay.time / 1000, t, ramp);
                delayFeedbackRef.current.gain.setTargetAtTime(dsp.delay.feedback, t, ramp);
                // We are using a summing bus, so "enabled" means we hear the delay output. 
                // Since I didn't create a dedicated OutputGain for delay, I'll hack it: 
                // If disabled, feedback is 0 and delayTime is tiny? No, better to have output gain.
                // For this quick impl, let's just kill feedback if disabled, effectively stopping the delay tail eventually.
            } else {
                 delayFeedbackRef.current.gain.setTargetAtTime(0, t, ramp);
            }
        }

        // Echo
         if (echoNodeRef.current && echoFeedbackRef.current) {
            if (dsp.echo.enabled) {
                echoNodeRef.current.delayTime.setTargetAtTime(dsp.echo.time / 1000, t, ramp);
                echoFeedbackRef.current.gain.setTargetAtTime(dsp.echo.decay, t, ramp);
            } else {
                echoFeedbackRef.current.gain.setTargetAtTime(0, t, ramp);
            }
        }

        // Reverb
        if (reverbNodeRef.current && reverbMixRef.current) {
            if (dsp.reverb.enabled) {
                // If buffer not set or size changed significantly, rebuild (expensive, do sparingly)
                // For prototype, we just set gain.
                if (!reverbNodeRef.current.buffer) {
                     reverbNodeRef.current.buffer = buildImpulse(audioContextRef.current, 2.0, 2.0); // Fixed room
                }
                reverbMixRef.current.gain.setTargetAtTime(dsp.reverb.mix, t, ramp);
            } else {
                reverbMixRef.current.gain.setTargetAtTime(0, t, ramp);
            }
        }

        // Master Limiter
        if (dsp.master.enabled && limiterNodeRef.current) {
             // Limiter is always "on" structurally, but we can adjust threshold or post-gain
             masterGainNodeRef.current?.gain.setTargetAtTime(dsp.master.gain, t, ramp);
        } else {
             masterGainNodeRef.current?.gain.setTargetAtTime(1.0, t, ramp);
        }

    }, [dsp]);

    // --- Track Logic ---
    useEffect(() => {
        if (!audioContextRef.current) return;
        const t = audioContextRef.current.currentTime;
        const ramp = 0.05;
        const anySolo = tracks.some(t => t.solo);

        tracks.forEach(track => {
            let nodeGroup = trackNodesRef.current.get(track.id);
            if (!nodeGroup) {
                const gain = audioContextRef.current!.createGain();
                const pan = audioContextRef.current!.createStereoPanner();
                gain.connect(pan);
                pan.connect(masterInputNodeRef.current!);
                nodeGroup = { gain, pan };
                trackNodesRef.current.set(track.id, nodeGroup);
            }
            let effectiveGain = track.volume;
            if (track.muted) effectiveGain = 0;
            if (anySolo && !track.solo) effectiveGain = 0;
            nodeGroup.gain.gain.setTargetAtTime(effectiveGain, t, ramp);
            nodeGroup.pan.pan.setTargetAtTime(track.pan, t, ramp);
        });
    }, [tracks]);

    const addNewTrack = (name: string, buffer: AudioBuffer | null = null) => {
        const id = crypto.randomUUID();
        const peaks = buffer ? generatePeaks(buffer) : [];
        if (buffer && buffer.duration > duration) setDuration(buffer.duration);

        const newTrack: Track = {
            id,
            name,
            volume: 1.0,
            pan: 0,
            muted: false,
            solo: false,
            armed: false,
            buffer,
            peaks,
            color: TRACK_COLORS[tracks.length % TRACK_COLORS.length],
            height: 64 
        };
        setTracks(prev => [...prev, newTrack]);
    };

    const deleteTrack = (id: string) => {
        setTracks(prev => prev.filter(t => t.id !== id));
        const nodes = trackNodesRef.current.get(id);
        if (nodes) {
            nodes.source?.stop();
            nodes.source?.disconnect();
            nodes.gain.disconnect();
            trackNodesRef.current.delete(id);
        }
    };

    const generatePeaks = (buffer: AudioBuffer) => {
        const channelData = buffer.getChannelData(0);
        const samples = 400;
        const blockSize = Math.floor(channelData.length / samples);
        const peaks = [];
        for (let i = 0; i < samples; i++) {
            const start = i * blockSize;
            let sum = 0;
            for (let j = 0; j < blockSize; j++) sum += Math.abs(channelData[start + j]);
            peaks.push(sum / blockSize);
        }
        const max = Math.max(...peaks, 0.01);
        return peaks.map(p => p / max);
    };

    // --- Transport Logic (Updated with Shuttle) ---
    const play = (offset: number) => {
        if (!audioContextRef.current) return;
        if (audioContextRef.current.state === 'suspended') audioContextRef.current.resume();

        tracks.forEach(t => {
            const nodes = trackNodesRef.current.get(t.id);
            if (nodes?.source) {
                try { nodes.source.stop(); } catch(e){}
                nodes.source.disconnect();
            }
        });

        tracks.forEach(t => {
            if (t.buffer) {
                const nodes = trackNodesRef.current.get(t.id);
                if (nodes) {
                    const source = audioContextRef.current!.createBufferSource();
                    source.buffer = t.buffer;
                    source.connect(nodes.gain);
                    source.start(0, offset);
                    nodes.source = source;
                }
            }
        });

        startTimeRef.current = audioContextRef.current.currentTime;
        startOffsetRef.current = offset;
        setIsPlaying(true);
        requestRef.current = requestAnimationFrame(animate);
    };

    const stop = () => {
        tracks.forEach(t => {
            const nodes = trackNodesRef.current.get(t.id);
            if (nodes?.source) {
                try { nodes.source.stop(); } catch(e){}
                nodes.source.disconnect();
                nodes.source = undefined;
            }
        });
        setIsPlaying(false);
        if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };

    const togglePlayback = () => {
        if (isPlaying) {
            stop();
            if (audioContextRef.current) {
                const elapsed = audioContextRef.current.currentTime - startTimeRef.current;
                setCurrentTime(Math.min(startOffsetRef.current + elapsed, duration));
            }
        } else {
            if (currentTime >= duration) { setCurrentTime(0); play(0); } else { play(currentTime); }
        }
    };

    const shuttle = (seconds: number) => {
        const wasPlaying = isPlaying;
        if (wasPlaying) stop();
        
        let newTime = currentTime + seconds;
        if (newTime < 0) newTime = 0;
        if (newTime > duration) newTime = duration;
        
        setCurrentTime(newTime);
        startOffsetRef.current = newTime; // Ensure next play starts from here
        
        if (wasPlaying) play(newTime);
    };

    const jumpToStart = () => {
        const wasPlaying = isPlaying;
        if (wasPlaying) stop();
        setCurrentTime(0);
        startOffsetRef.current = 0;
        if (wasPlaying) play(0);
    };

    const animate = () => {
        if (!isPlaying || !audioContextRef.current) return;
        const elapsed = audioContextRef.current.currentTime - startTimeRef.current;
        const newTime = startOffsetRef.current + elapsed;
        if (newTime >= duration) { 
            setCurrentTime(duration); 
            stop(); 
        } else { 
            setCurrentTime(newTime); 
            requestRef.current = requestAnimationFrame(animate); 
        }
    };

    const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const percent = Math.max(0, Math.min(1, x / rect.width));
        const time = percent * duration;
        setCurrentTime(time);
        if (isPlaying) play(time);
    };

    // --- Recording Logic ---
    const toggleRecording = async () => {
        if (isRecording) {
            mediaRecorderRef.current?.stop();
            setIsRecording(false);
            stop();
        } else {
            const armedTrack = tracks.find(t => t.armed);
            if (!armedTrack) {
                alert("Please arm a track (R button) to record.");
                return;
            }
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                const mediaRecorder = new MediaRecorder(stream);
                mediaRecorderRef.current = mediaRecorder;
                recordedChunksRef.current = [];
                mediaRecorder.ondataavailable = (e) => {
                    if (e.data.size > 0) recordedChunksRef.current.push(e.data);
                };
                mediaRecorder.onstop = async () => {
                    const blob = new Blob(recordedChunksRef.current, { type: 'audio/webm' });
                    const arrayBuffer = await blob.arrayBuffer();
                    const audioBuffer = await audioContextRef.current!.decodeAudioData(arrayBuffer);
                    setTracks(prev => prev.map(t => {
                        if (t.id === armedTrack.id) {
                            return { ...t, buffer: audioBuffer, peaks: generatePeaks(audioBuffer) };
                        }
                        return t;
                    }));
                    stream.getTracks().forEach(track => track.stop());
                };
                play(currentTime);
                mediaRecorder.start();
                setIsRecording(true);
            } catch (e) {
                console.error("Recording error:", e);
                alert("Could not access microphone.");
            }
        }
    };

    const onFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const r = new FileReader();
        r.onload = async (ev) => {
            if (ev.target?.result && audioContextRef.current) {
                const buf = await audioContextRef.current.decodeAudioData(ev.target.result as ArrayBuffer);
                addNewTrack(file.name, buf);
            }
        };
        r.readAsArrayBuffer(file);
    };

    const onRegistrySelect = async (item: MediaItem) => {
        setShowRegistryPicker(false);
        const url = item.uri.startsWith('http') ? item.uri : 'https://actions.google.com/sounds/v1/ambiences/coffee_shop.ogg'; 
        try {
            const res = await fetch(url);
            const buf = await res.arrayBuffer();
            const decoded = await audioContextRef.current!.decodeAudioData(buf);
            addNewTrack(item.uri.split('/').pop() || 'Asset', decoded);
        } catch(e) { console.error(e); }
    };

    const fmt = (s: number) => {
        const m = Math.floor(s/60); 
        const sec = Math.floor(s%60); 
        return `${m}:${sec.toString().padStart(2,'0')}`;
    };

    return (
        <div className="h-full flex flex-col font-sans text-[#3A3836] relative animate-in fade-in duration-500">
            
            {/* Header */}
            <div className="mb-4 px-2 flex items-center justify-between shrink-0">
                <div>
                    <h2 className="text-3xl font-extrabold tracking-tight text-gray-900 flex items-center gap-3">
                        <span className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-500/30">
                            <Activity size={20} />
                        </span>
                        Audio Engineer
                    </h2>
                    <p className="text-gray-500 text-sm font-medium mt-1 ml-1">Multi-track DSP Workstation</p>
                </div>
                <div className="flex gap-2">
                    <button onClick={() => setShowRegistryPicker(true)} className="px-4 py-2 bg-white hover:bg-gray-50 text-gray-700 rounded-lg text-sm font-bold shadow-sm border border-gray-200 flex items-center gap-2">
                        <Database size={16} /> Library
                    </button>
                    <label className="px-4 py-2 bg-[#FF5500] hover:bg-[#e64d00] text-white rounded-lg text-sm font-bold shadow-lg shadow-orange-500/20 flex items-center gap-2 cursor-pointer transition-transform active:scale-95">
                        <Plus size={16} /> Add Track
                        <input type="file" hidden onChange={onFileUpload} accept="audio/*" />
                    </label>
                </div>
            </div>

            <div className="flex-1 glass-card rounded-[2rem] p-6 relative flex flex-col overflow-hidden">
                
                {/* --- TOP ROW: TRANSPORT + DIGITAL HARMONY RACK --- */}
                <div className="flex flex-col md:flex-row gap-4 mb-4 h-auto md:h-48 shrink-0">
                    
                    {/* Transport Control & Timecode */}
                    <div className="w-full md:w-64 bg-gray-100 rounded-2xl p-4 flex flex-col justify-between shrink-0 shadow-inner">
                        <div className="flex justify-between items-center">
                            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Transport</span>
                            <Activity size={16} className="text-gray-400" />
                        </div>
                        
                        <div className="bg-black/5 rounded-xl p-3 mb-2 font-mono text-center">
                            <div className="text-3xl font-bold text-gray-800 leading-none">{fmt(currentTime)}</div>
                            <div className="text-xs text-gray-400">{(currentTime % 1).toFixed(3)}</div>
                        </div>

                        <div className="flex justify-center gap-2 flex-wrap">
                            <button onClick={jumpToStart} className="w-8 h-8 rounded-lg bg-white text-gray-600 flex items-center justify-center shadow-sm border border-gray-200 hover:bg-gray-50" title="Jump to Start">
                                <SkipBack size={14} fill="currentColor" />
                            </button>
                            <button onClick={() => shuttle(-5)} className="w-8 h-8 rounded-lg bg-white text-gray-600 flex items-center justify-center shadow-sm border border-gray-200 hover:bg-gray-50" title="Rewind 5s">
                                <Rewind size={14} fill="currentColor" />
                            </button>
                             <button onClick={togglePlayback} className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${isPlaying ? 'bg-emerald-500 text-white shadow-lg' : 'bg-gray-800 text-white shadow-md'}`}>
                                {isPlaying ? <Pause size={20} fill="currentColor"/> : <Play size={20} fill="currentColor" className="ml-1"/>}
                            </button>
                            <button onClick={() => shuttle(5)} className="w-8 h-8 rounded-lg bg-white text-gray-600 flex items-center justify-center shadow-sm border border-gray-200 hover:bg-gray-50" title="Fast Forward 5s">
                                <FastForward size={14} fill="currentColor" />
                            </button>
                             <button onClick={stop} className="w-8 h-8 rounded-lg bg-white text-gray-600 flex items-center justify-center shadow-sm border border-gray-200 hover:bg-gray-50" title="Stop">
                                <Square size={14} fill="currentColor" />
                            </button>
                        </div>
                        <div className="flex justify-center mt-2">
                             <button onClick={toggleRecording} className={`w-full py-1 rounded-lg flex items-center justify-center gap-2 text-xs font-bold uppercase transition-all ${isRecording ? 'bg-red-50 text-white animate-pulse' : 'bg-red-50 text-red-500 border border-red-100 hover:bg-red-100'}`}>
                                <Circle size={10} fill="currentColor" /> {isRecording ? 'Rec Live' : 'Arm Rec'}
                            </button>
                        </div>
                    </div>

                    {/* Digital Harmony AI Rack Unit */}
                    <DigitalHarmonyRackUnit state={digitalHarmony} onChange={setDigitalHarmony} />
                </div>

                {/* --- DSP RACK (Compact Stompboxes) --- */}
                <div className="flex-none h-44 mb-4 bg-gray-800/5 rounded-2xl border border-gray-200/50 p-2 overflow-x-auto custom-scrollbar flex items-center gap-2">
                    
                    {/* Cleanup Module */}
                    <RackModule 
                        label="De-Noise" 
                        color="purple" 
                        enabled={dsp.cleanup.enabled} 
                        onToggle={() => setDsp(d => ({...d, cleanup: {...d.cleanup, enabled: !d.cleanup.enabled}}))}
                    >
                        <RackSlider 
                            label="Reduction" 
                            value={dsp.cleanup.reduction} min={0} max={1} step={0.01} 
                            onChange={(v) => setDsp(d => ({...d, cleanup: {...d.cleanup, reduction: v}}))}
                        />
                    </RackModule>

                    {/* PreAmp Module */}
                    <RackModule 
                        label="Pre-Amp" 
                        color="indigo" 
                        enabled={dsp.preamp.enabled} 
                        onToggle={() => setDsp(d => ({...d, preamp: {...d.preamp, enabled: !d.preamp.enabled}}))}
                    >
                        <RackSlider 
                            label="Input" 
                            value={dsp.preamp.gain} min={0} max={2} step={0.05} 
                            onChange={(v) => setDsp(d => ({...d, preamp: {...d.preamp, gain: v}}))}
                        />
                    </RackModule>

                    {/* EQ Module */}
                    <RackModule 
                        label="EQ-500" 
                        color="pink" 
                        enabled={dsp.eq.enabled} 
                        onToggle={() => setDsp(d => ({...d, eq: {...d.eq, enabled: !d.eq.enabled}}))}
                    >
                        <RackSlider 
                            label="Lo" unit="dB"
                            value={dsp.eq.lowGain} min={-12} max={12} step={1} 
                            onChange={(v) => setDsp(d => ({...d, eq: {...d.eq, lowGain: v}}))}
                        />
                        <RackSlider 
                            label="Hi" unit="dB"
                            value={dsp.eq.highGain} min={-12} max={12} step={1} 
                            onChange={(v) => setDsp(d => ({...d, eq: {...d.eq, highGain: v}}))}
                        />
                    </RackModule>

                    {/* Compressor Module */}
                    <RackModule 
                        label="Compressor" 
                        color="orange" 
                        enabled={dsp.compressor.enabled} 
                        onToggle={() => setDsp(d => ({...d, compressor: {...d.compressor, enabled: !d.compressor.enabled}}))}
                    >
                        <RackSlider 
                            label="Thresh" unit="dB"
                            value={dsp.compressor.threshold} min={-60} max={0} step={1} 
                            onChange={(v) => setDsp(d => ({...d, compressor: {...d.compressor, threshold: v}}))}
                        />
                        <RackSlider 
                            label="Ratio" unit=":1"
                            value={dsp.compressor.ratio} min={1} max={20} step={0.5} 
                            onChange={(v) => setDsp(d => ({...d, compressor: {...d.compressor, ratio: v}}))}
                        />
                    </RackModule>

                    {/* Echo Module */}
                    <RackModule 
                        label="Echo" 
                        color="teal" 
                        enabled={dsp.echo.enabled} 
                        onToggle={() => setDsp(d => ({...d, echo: {...d.echo, enabled: !d.echo.enabled}}))}
                    >
                        <RackSlider 
                            label="Time" unit="ms"
                            value={dsp.echo.time} min={10} max={1000} step={10} 
                            onChange={(v) => setDsp(d => ({...d, echo: {...d.echo, time: v}}))}
                        />
                        <RackSlider 
                            label="Decay"
                            value={dsp.echo.decay} min={0} max={1} step={0.01} 
                            onChange={(v) => setDsp(d => ({...d, echo: {...d.echo, decay: v}}))}
                        />
                    </RackModule>

                    {/* Reverb Module */}
                    <RackModule 
                        label="Reverb" 
                        color="blue" 
                        enabled={dsp.reverb.enabled} 
                        onToggle={() => setDsp(d => ({...d, reverb: {...d.reverb, enabled: !d.reverb.enabled}}))}
                    >
                        <RackSlider 
                            label="Size" 
                            value={dsp.reverb.size} min={0} max={1} step={0.01} 
                            onChange={(v) => setDsp(d => ({...d, reverb: {...d.reverb, size: v}}))}
                        />
                        <RackSlider 
                            label="Mix" 
                            value={dsp.reverb.mix} min={0} max={1} step={0.01} 
                            onChange={(v) => setDsp(d => ({...d, reverb: {...d.reverb, mix: v}}))}
                        />
                    </RackModule>

                    {/* Delay Module */}
                    <RackModule 
                        label="Delay" 
                        color="cyan" 
                        enabled={dsp.delay.enabled} 
                        onToggle={() => setDsp(d => ({...d, delay: {...d.delay, enabled: !d.delay.enabled}}))}
                    >
                        <RackSlider 
                            label="Time" unit="ms"
                            value={dsp.delay.time} min={0} max={2000} step={10} 
                            onChange={(v) => setDsp(d => ({...d, delay: {...d.delay, time: v}}))}
                        />
                        <RackSlider 
                            label="Feed" 
                            value={dsp.delay.feedback} min={0} max={0.9} step={0.01} 
                            onChange={(v) => setDsp(d => ({...d, delay: {...d.delay, feedback: v}}))}
                        />
                    </RackModule>

                    {/* Limiter Module */}
                    <RackModule 
                        label="Limiter" 
                        color="red" 
                        enabled={dsp.master.enabled} 
                        onToggle={() => setDsp(d => ({...d, master: {...d.master, enabled: !d.master.enabled}}))}
                    >
                        <RackSlider 
                            label="Output" 
                            value={dsp.master.gain} min={0} max={2} step={0.05} 
                            onChange={(v) => setDsp(d => ({...d, master: {...d.master, gain: v}}))}
                        />
                    </RackModule>

                </div>

                {/* --- TIMELINE AREA --- */}
                <div className="bg-gray-50 rounded-2xl border border-gray-200 relative flex flex-col overflow-hidden h-[340px] shrink-0">
                    
                    {/* Ruler */}
                    <div className="h-8 bg-white border-b border-gray-200 flex shrink-0 select-none">
                        <div className="w-[220px] shrink-0 border-r border-gray-100 bg-gray-50/50 flex items-center px-4">
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Track Header</span>
                        </div>
                        <div className="flex-1 relative overflow-hidden" ref={containerRef} onClick={handleSeek}>
                            <div className="absolute inset-0 flex items-end pb-1 text-[9px] font-mono text-gray-400 pointer-events-none">
                                {Array.from({ length: 20 }).map((_, i) => (
                                    <div key={i} className="flex-1 border-l border-gray-200 pl-1 h-3">{fmt(i * (duration / 20))}</div>
                                ))}
                            </div>
                            <div 
                                className="absolute top-0 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px] border-t-[#FF5500] transform -translate-x-1/2 transition-none z-20 pointer-events-none"
                                style={{ left: `${(currentTime / duration) * 100}%` }}
                            ></div>
                        </div>
                    </div>

                    {/* Tracks Scroll Area */}
                    <div className="flex-1 overflow-y-auto custom-scrollbar relative">
                        {tracks.map(track => (
                            <div key={track.id} className="flex h-16 border-b border-gray-200 bg-white group hover:bg-gray-50/50 transition-colors">
                                
                                <div className="w-[220px] shrink-0 border-r border-gray-100 p-2 flex flex-col justify-between bg-gray-50/30">
                                    <div className="flex items-center justify-between mb-1">
                                        <input 
                                            value={track.name}
                                            onChange={(e) => setTracks(prev => prev.map(t => t.id === track.id ? {...t, name: e.target.value} : t))}
                                            className="bg-transparent text-xs font-bold text-gray-800 w-24 focus:outline-none focus:bg-white rounded px-1"
                                        />
                                        <div className="flex gap-1">
                                            <button 
                                                onClick={() => setTracks(prev => prev.map(t => t.id === track.id ? {...t, armed: !t.armed} : t))}
                                                className={`w-5 h-5 rounded text-[9px] font-bold flex items-center justify-center transition-colors ${track.armed ? 'bg-red-500 text-white' : 'bg-gray-200 text-gray-500 hover:bg-gray-300'}`}
                                            >R</button>
                                            <button 
                                                onClick={() => setTracks(prev => prev.map(t => t.id === track.id ? {...t, solo: !t.solo} : t))}
                                                className={`w-5 h-5 rounded text-[9px] font-bold flex items-center justify-center transition-colors ${track.solo ? 'bg-yellow-400 text-yellow-900' : 'bg-gray-200 text-gray-500 hover:bg-gray-300'}`}
                                            >S</button>
                                            <button 
                                                onClick={() => setTracks(prev => prev.map(t => t.id === track.id ? {...t, muted: !t.muted} : t))}
                                                className={`w-5 h-5 rounded text-[9px] font-bold flex items-center justify-center transition-colors ${track.muted ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-500 hover:bg-gray-300'}`}
                                            >M</button>
                                        </div>
                                    </div>
                                    
                                    <div className="flex items-end gap-2">
                                        <div className="flex-1 space-y-1">
                                            <div className="flex justify-between text-[8px] font-bold text-gray-400">
                                                <span>VOL</span> <span>{Math.round(track.volume * 100)}%</span>
                                            </div>
                                            <input 
                                                type="range" min="0" max="1.5" step="0.01" 
                                                value={track.volume}
                                                onChange={(e) => setTracks(prev => prev.map(t => t.id === track.id ? {...t, volume: parseFloat(e.target.value)} : t))}
                                                className="w-full h-1 bg-gray-200 rounded-full appearance-none accent-gray-600"
                                            />
                                        </div>
                                        <div className="w-8 space-y-1">
                                            <div className="text-[8px] font-bold text-gray-400 text-center">PAN</div>
                                            <div className="flex justify-center">
                                                <div 
                                                    className="w-5 h-5 rounded-full border border-gray-300 bg-white relative cursor-pointer"
                                                    onClick={() => setTracks(prev => prev.map(t => t.id === track.id ? {...t, pan: 0} : t))} 
                                                >
                                                    <div 
                                                        className="absolute top-0 left-1/2 w-0.5 h-2 bg-gray-600 origin-bottom rounded-full"
                                                        style={{ transform: `translateX(-50%) rotate(${track.pan * 45}deg)` }}
                                                    ></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex-1 relative cursor-crosshair" onClick={handleSeek}>
                                    {track.buffer ? (
                                        <div className="absolute inset-0 flex items-center px-0.5">
                                            <div className="w-full h-12 flex items-center gap-px opacity-80">
                                                {track.peaks.map((peak, i) => (
                                                    <div 
                                                        key={i} 
                                                        style={{ height: `${Math.max(5, peak * 100)}%`, backgroundColor: track.color }}
                                                        className="flex-1 rounded-full opacity-60"
                                                    ></div>
                                                ))}
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button 
                                                onClick={() => document.getElementById(`upload-${track.id}`)?.click()}
                                                className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 rounded-lg text-xs font-bold text-gray-500 hover:bg-gray-200"
                                            >
                                                <Upload size={14} /> Import Audio
                                            </button>
                                            <input id={`upload-${track.id}`} type="file" hidden onChange={onFileUpload} accept="audio/*" />
                                        </div>
                                    )}
                                    <div className="absolute inset-0 flex pointer-events-none">
                                         {Array.from({ length: 10 }).map((_, i) => (
                                            <div key={i} className="flex-1 border-r border-gray-100/50"></div>
                                        ))}
                                    </div>
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); deleteTrack(track.id); }}
                                        className="absolute top-2 right-2 p-1.5 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                                    >
                                        <Trash2 size={14} />
                                    </button>
                                </div>
                            </div>
                        ))}
                        
                        <div 
                            className="absolute top-0 bottom-0 w-px bg-[#FF5500] pointer-events-none z-10 transition-none"
                            style={{ left: `${(currentTime / duration) * 100}%` }}
                        >
                            <div className="absolute top-0 -translate-x-1/2 -mt-1 p-1 bg-[#FF5500] text-white text-[9px] font-bold rounded shadow-sm">
                                {fmt(currentTime)}
                            </div>
                        </div>

                        <div className="p-2 border-b border-dashed border-gray-200">
                             <button onClick={() => addNewTrack(`Audio ${tracks.length + 1}`)} className="w-full py-2 border-2 border-dashed border-gray-200 rounded-xl text-gray-400 font-bold text-xs hover:border-gray-400 hover:text-gray-600 transition-colors flex items-center justify-center gap-2">
                                <Plus size={14} /> Add Empty Track
                             </button>
                        </div>
                    </div>
                </div>

            </div>

             {showRegistryPicker && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm" onClick={() => setShowRegistryPicker(false)}>
                    <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-bold text-gray-900">Select Audio from Registry</h3>
                            <button onClick={() => setShowRegistryPicker(false)} className="p-1 hover:bg-gray-100 rounded-full">
                                <X size={20} className="text-gray-500" />
                            </button>
                        </div>
                        <div className="max-h-60 overflow-y-auto custom-scrollbar space-y-2">
                            {MOCK_MEDIA.filter(m => m.source_type.includes('audio')).map(item => (
                                <button 
                                    key={item.id}
                                    onClick={() => onRegistrySelect(item)}
                                    className="w-full flex items-center gap-3 p-3 hover:bg-gray-50 rounded-xl transition-colors border border-transparent hover:border-gray-200"
                                >
                                    <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-lg flex items-center justify-center">
                                        <Music size={20} />
                                    </div>
                                    <div className="text-left flex-1 min-w-0">
                                        <div className="text-sm font-bold text-gray-900 truncate">{item.uri.split('/').pop()}</div>
                                        <div className="text-xs text-gray-500">{item.id} • {Math.floor(item.duration_seconds / 60)}:{String(item.duration_seconds % 60).padStart(2, '0')}</div>
                                    </div>
                                    <ChevronRight size={16} className="text-gray-300" />
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};