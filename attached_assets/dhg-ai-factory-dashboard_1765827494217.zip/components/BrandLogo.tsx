import React from 'react';

interface BrandLogoProps {
  size?: number;
  className?: string;
  animate?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ size = 32, className = '', animate = false }) => {
  const style = { width: size, height: size, minWidth: size, minHeight: size };

  return (
    <div 
        className={`relative flex items-center justify-center rounded-full overflow-hidden shadow-sm shrink-0 select-none ${className} ${animate ? 'animate-spin' : ''}`}
        style={style}
        role="img"
        aria-label="Digital Harmony AI Logo"
    >
      <svg 
        viewBox="0 0 100 100" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        {/* Background: Warm Stone (Brand Light) */}
        <circle cx="50" cy="50" r="50" fill="#F5F2EB" />
        
        {/* Main Logo Circle: White for high contrast */}
        <circle cx="50" cy="50" r="45" fill="#FFFFFF" stroke="#E0D8C8" strokeWidth="1"/>
        
        {/* Sun Gradient - Blaze Orange */}
        <defs>
          <linearGradient id="sunGradient" x1="50" y1="50" x2="50" y2="35" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FF5500"/>
            <stop offset="1" stopColor="#FF9500"/>
          </linearGradient>
        </defs>

        {/* Rising Sun */}
        <path d="M30 50 A20 20 0 0 1 70 50" fill="url(#sunGradient)" />
        
        {/* Sun Rays (Charcoal for visibility) */}
        <g stroke="#3A3836" strokeWidth="2" strokeLinecap="round">
          <line x1="50" y1="26" x2="50" y2="15" />
          <line x1="68" y1="32" x2="76" y2="24" />
          <line x1="32" y1="32" x2="24" y2="24" />
          <line x1="74" y1="50" x2="85" y2="50" />
          <line x1="26" y1="50" x2="15" y2="50" />
        </g>

        {/* Horizon Line */}
        <line x1="15" y1="50" x2="85" y2="50" stroke="#3A3836" strokeWidth="2" />

        {/* Circuitry Bottom (Tech Roots) - Charcoal on White */}
        <path d="M85 50 A35 35 0 0 1 15 50" fill="none" />
        
        {/* Circuit Lines */}
        <g stroke="#3A3836" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            {/* Center Trunk */}
            <path d="M50 50 V70" />
            <circle cx="50" cy="74" r="3" fill="#FF5500" stroke="none"/>
            
            {/* Left Branch */}
            <path d="M40 50 V60 L30 68 V75" />
            <circle cx="30" cy="78" r="2.5" fill="#3A3836" stroke="none"/>
            
            {/* Right Branch */}
            <path d="M60 50 V60 L70 68 V75" />
            <circle cx="70" cy="78" r="2.5" fill="#3A3836" stroke="none"/>
        </g>
      </svg>
    </div>
  );
};