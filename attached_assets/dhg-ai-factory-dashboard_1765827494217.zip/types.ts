
// --- DHG REGISTRY SCHEMA (Strict Alignment with Deployment Plan) ---

export enum MediaStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED'
}

export enum ServiceState {
  HEALTHY = 'HEALTHY',
  DEGRADED = 'DEGRADED',
  DOWN = 'DOWN'
}

// Table: media
export interface RegistryMedia {
  id: string;               // UUID PK
  uri: string;              // text
  source_type: string;      // text
  status: MediaStatus;      // enum
  duration_seconds: number; // numeric
  metadata: Record<string, any>; // JSONB
  created_at: string;       // timestamptz
}

// Table: transcripts
export interface RegistryTranscript {
  id: string;               // UUID PK
  media_id: string;         // FK -> media.id
  text: string;             // text
  confidence: number;       // numeric (0-1)
  metadata: Record<string, any>; // JSONB
}

// Table: segments (Vector Ready)
export interface RegistrySegment {
  id: string;               // UUID PK
  media_id: string;         // FK -> media.id
  transcript_id: string;    // FK -> transcripts.id
  start_time: number;       // numeric
  end_time: number;         // numeric
  text: string;             // text
  confidence: number;       // numeric
  embedding: number[];      // VECTOR (Array of floats)
}

// Table: events (Observability & Audit)
export interface RegistryEvent {
  id: string;               // UUID PK
  created_at: string;       // timestamptz
  source_service: string;   // text (e.g., 'dhg-orchestrator')
  event_type: string;       // text (e.g., 'JOB_STARTED')
  payload: Record<string, any>; // JSONB
  correlation_id?: string;  // text (for tracing across services)
  level?: 'INFO' | 'WARN' | 'ERROR'; // Optional helper for UI coloring
  message?: string; // Helper for simple display
}

// --- Application UI Types (Derived or Auxiliary) ---

export interface ServiceHealth {
  name: string;
  status: ServiceState;
  latencyMs: number;
  uptime: string;
  version: string;
}

export interface MetricPoint {
  time: string;
  value: number;
}

export interface SystemMetrics {
  gpuUtilization: MetricPoint[];     // matches: gpu_utilization
  asrLatency: MetricPoint[];         // matches: asr_latency_seconds
  registryWrites: MetricPoint[];     // matches: registry_write_latency_ms
  orchestratorQueue: MetricPoint[];  // matches: orchestrator_queue_depth
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isThinking?: boolean;
}

export type ViewType = 'DASHBOARD' | 'MEDIA' | 'DESIGN' | 'AUDIO';

export interface ViewProps {
  onInspectItem?: (item: RegistryMedia) => void;
}

// Legacy aliases for backward compatibility during refactor
export type MediaItem = RegistryMedia; 
export type LogEvent = RegistryEvent;

export interface DesignSettings {
  imageCount: number;
  innovationLevel: number;
  themeMode: 'light' | 'dark';
  selectedStyle: string;
  selectedPalette: string;
  interfaceType: string;
  aspectRatio: string;
}

export interface AudioSettings {
  targetPlatformId: string;
  smartClarity: boolean;
  autoDucking: boolean;
  eqProfile: string;
}
