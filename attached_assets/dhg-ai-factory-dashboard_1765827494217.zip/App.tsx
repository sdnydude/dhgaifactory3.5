import React, { useState, useEffect, useRef } from 'react';
import { 
  Menu, X, Zap, Database, Palette, MessageSquare, ChevronRight, Plus, Settings, HelpCircle, LogOut, User, Search, PanelLeft,
  Layout, Smartphone, Monitor, Watch, Share2, MonitorPlay, Square, RectangleHorizontal, RectangleVertical, Grid, Moon, Sun, Layers, Music, Sliders, Mic2, Volume2, ChevronDown, GripVertical
} from 'lucide-react';
import { DashboardView } from './components/DashboardView';
import { MediaManager } from './components/MediaManager';
import { AIOpsChat, AIOpsChatRef } from './components/AIOpsChat';
import { DesignConcept } from './components/DesignConcept';
import { AudioStudio } from './components/AudioStudio';
import { BrandLogo } from './components/BrandLogo';
import { LiveSystemProvider } from './contexts/LiveSystemContext';
import { ViewType, ChatMessage, DesignSettings, AudioSettings } from './types';
import { TARGET_PLATFORMS } from './services/mockData';

// Mock Data Structure for History Items
interface HistoryItem {
  id: string;
  label: string;
  category: 'Today' | 'Yesterday' | 'Previous 7 Days';
  view: ViewType;
  indicatorColor?: string;
  messages: { role: 'user' | 'model', text: string }[];
}

const HISTORY_ITEMS: HistoryItem[] = [
  {
    id: 'h1',
    label: 'System diagnostics report',
    category: 'Today',
    view: 'DASHBOARD',
    indicatorColor: 'bg-emerald-500/50',
    messages: [
      { role: 'user', text: 'Run a full system diagnostics report.' },
      { role: 'model', text: 'Initiating Factory 7 diagnostic scan...\n\n**Analysis Complete:**\n- **Core Services:** 5/5 Healthy\n- **GPU Cluster:** 42% Utilization\n- **Storage:** 850TB Available\n\nNo critical anomalies detected in the last 24 hours.' }
    ]
  },
  {
    id: 'h2',
    label: 'Design concept v4',
    category: 'Today',
    view: 'DESIGN',
    indicatorColor: 'bg-orange-500/50',
    messages: [
      { role: 'user', text: 'I need a new look for the admin panel. Something modern.' },
      { role: 'model', text: 'I suggest a "Swiss Minimal" approach with a focus on typography and whitespace. Let me generate a concept for you.' },
      { role: 'model', text: 'Here is Concept v4. Note the use of the grid layout and the DHG Orange accents.' }
    ]
  },
  {
    id: 'h3',
    label: 'Registry migration logs',
    category: 'Yesterday',
    view: 'MEDIA',
    messages: [
      { role: 'user', text: 'Check the logs for the registry migration job.' },
      { role: 'model', text: 'Scanning `dhg-registry-db` logs for migration events...\n\n`[INFO] Migration started at 02:00:01 UTC`\n`[INFO] Table "assets" altered successfully`\n`[INFO] Migration completed in 4.2s`\n\nThe operation was successful with no data loss.' }
    ]
  }
];

export const App = () => {
    const [activeView, setActiveView] = useState<ViewType>('DASHBOARD');
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isChatOpen, setIsChatOpen] = useState(true);
    
    // Global Design Settings
    const [designSettings, setDesignSettings] = useState<DesignSettings>({
        imageCount: 2,
        innovationLevel: 50,
        themeMode: 'dark',
        selectedStyle: 'Glassmorphism',
        selectedPalette: 'DHG System',
        interfaceType: 'Dashboard',
        aspectRatio: '16:9'
    });

    const [audioSettings, setAudioSettings] = useState<AudioSettings>({
        targetPlatformId: 'spotify',
        smartClarity: true,
        autoDucking: true,
        eqProfile: 'neutral'
    });

    const chatRef = useRef<AIOpsChatRef>(null);

    const handleAskAssistant = (prompt: string) => {
        setIsChatOpen(true);
        // Small delay to ensure ref is mounted if chat was closed
        setTimeout(() => {
            chatRef.current?.sendMessage(prompt);
        }, 100);
    };

    return (
        <LiveSystemProvider>
            <div className="flex h-screen w-full bg-[#F5F2EB] text-[#3A3836] overflow-hidden relative selection:bg-[#FF5500] selection:text-white">
                
                {/* --- SIDEBAR --- */}
                <aside 
                    className={`
                        fixed inset-y-0 left-0 z-40 w-72 bg-[#E6DCC8]/80 backdrop-blur-xl border-r border-white/40 shadow-2xl transition-transform duration-300 ease-out
                        md:relative md:translate-x-0
                        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
                    `}
                >
                    <div className="flex flex-col h-full p-5">
                        
                        {/* Logo Area */}
                        <div className="flex items-center gap-3 mb-8 pl-2">
                            <BrandLogo size={40} />
                            <div>
                                <h1 className="text-lg font-bold tracking-tight text-[#3A3836] leading-none font-serif italic">Factory 7</h1>
                                <span className="text-[10px] font-bold text-[#8A8886] uppercase tracking-[0.2em]">Digital Harmony</span>
                            </div>
                        </div>

                        {/* Navigation */}
                        <nav className="space-y-1.5 flex-1">
                            <button 
                                onClick={() => setActiveView('DASHBOARD')}
                                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all ${
                                    activeView === 'DASHBOARD' 
                                    ? 'bg-white shadow-sm text-[#FF5500] ring-1 ring-black/5' 
                                    : 'text-[#5A5856] hover:bg-white/40 hover:text-[#3A3836]'
                                }`}
                            >
                                <Zap size={18} className={activeView === 'DASHBOARD' ? 'fill-current' : ''} />
                                Operations Center
                            </button>
                            
                            <button 
                                onClick={() => setActiveView('MEDIA')}
                                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all ${
                                    activeView === 'MEDIA' 
                                    ? 'bg-white shadow-sm text-[#FF5500] ring-1 ring-black/5' 
                                    : 'text-[#5A5856] hover:bg-white/40 hover:text-[#3A3836]'
                                }`}
                            >
                                <Database size={18} className={activeView === 'MEDIA' ? 'fill-current' : ''} />
                                Media Registry
                            </button>
                            
                            <button 
                                onClick={() => setActiveView('DESIGN')}
                                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all ${
                                    activeView === 'DESIGN' 
                                    ? 'bg-white shadow-sm text-[#FF5500] ring-1 ring-black/5' 
                                    : 'text-[#5A5856] hover:bg-white/40 hover:text-[#3A3836]'
                                }`}
                            >
                                <Palette size={18} className={activeView === 'DESIGN' ? 'fill-current' : ''} />
                                Design Studio
                            </button>

                            <button 
                                onClick={() => setActiveView('AUDIO')}
                                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all ${
                                    activeView === 'AUDIO' 
                                    ? 'bg-white shadow-sm text-[#FF5500] ring-1 ring-black/5' 
                                    : 'text-[#5A5856] hover:bg-white/40 hover:text-[#3A3836]'
                                }`}
                            >
                                <Music size={18} className={activeView === 'AUDIO' ? 'fill-current' : ''} />
                                Audio Engineer
                            </button>
                        </nav>

                         {/* Contextual Settings */}
                        <div className="bg-white/40 rounded-2xl p-4 border border-white/50 shadow-sm mb-4">
                            <h3 className="text-[10px] font-bold text-[#8A8886] uppercase tracking-wider mb-3 flex items-center gap-2">
                                <Sliders size={12} />
                                {activeView === 'DESIGN' ? 'Design Config' : activeView === 'AUDIO' ? 'Platform Target' : 'System Context'}
                            </h3>
                            
                            {activeView === 'DESIGN' ? (
                                <div className="space-y-3">
                                    <div className="space-y-1">
                                        <label className="text-xs font-semibold text-gray-600">Style Engine</label>
                                        <div className="relative">
                                            <select 
                                                value={designSettings.selectedStyle}
                                                onChange={(e) => setDesignSettings({...designSettings, selectedStyle: e.target.value})}
                                                className="w-full bg-white/60 text-xs font-bold rounded-lg px-2 py-2 border border-white/50 focus:outline-none appearance-none"
                                            >
                                                <option>Glassmorphism</option>
                                                <option>Neo-Brutalism</option>
                                                <option>Cyberpunk</option>
                                                <option>Swiss Minimal</option>
                                                <option>Social Media</option>
                                            </select>
                                            <ChevronDown size={14} className="absolute right-2 top-2.5 text-gray-400 pointer-events-none" />
                                        </div>
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-xs font-semibold text-gray-600">Theme</label>
                                        <div className="flex gap-1 bg-white/60 p-1 rounded-lg border border-white/50">
                                            <button 
                                                onClick={() => setDesignSettings({...designSettings, themeMode: 'light'})}
                                                className={`flex-1 flex items-center justify-center py-1 rounded-md transition-colors ${designSettings.themeMode === 'light' ? 'bg-white shadow-sm text-[#FF5500]' : 'text-gray-400'}`}
                                            >
                                                <Sun size={14} />
                                            </button>
                                            <button 
                                                onClick={() => setDesignSettings({...designSettings, themeMode: 'dark'})}
                                                className={`flex-1 flex items-center justify-center py-1 rounded-md transition-colors ${designSettings.themeMode === 'dark' ? 'bg-gray-800 shadow-sm text-white' : 'text-gray-400'}`}
                                            >
                                                <Moon size={14} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ) : activeView === 'AUDIO' ? (
                                <div className="space-y-3">
                                    <div className="space-y-1">
                                        <label className="text-xs font-semibold text-gray-600">Master Output</label>
                                        <div className="relative">
                                            <select 
                                                value={audioSettings.targetPlatformId}
                                                onChange={(e) => setAudioSettings({...audioSettings, targetPlatformId: e.target.value})}
                                                className="w-full bg-white/60 text-xs font-bold rounded-lg px-2 py-2 border border-white/50 focus:outline-none appearance-none"
                                            >
                                                {TARGET_PLATFORMS.map(p => (
                                                    <option key={p.id} value={p.id}>{p.label} ({p.lufs} LUFS)</option>
                                                ))}
                                            </select>
                                            <ChevronDown size={14} className="absolute right-2 top-2.5 text-gray-400 pointer-events-none" />
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <span className="text-xs font-semibold text-gray-600">Smart Clarity</span>
                                        <button 
                                            onClick={() => setAudioSettings({...audioSettings, smartClarity: !audioSettings.smartClarity})}
                                            className={`w-8 h-4 rounded-full transition-colors relative ${audioSettings.smartClarity ? 'bg-[#FF5500]' : 'bg-gray-300'}`}
                                        >
                                            <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full shadow-sm transition-transform ${audioSettings.smartClarity ? 'left-4.5' : 'left-0.5'}`}></div>
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <div className="text-xs text-gray-500 leading-relaxed">
                                    System running in <strong className="text-emerald-600">Simulation Mode</strong>. 
                                    Live metrics are being generated locally.
                                </div>
                            )}
                        </div>

                        {/* User Profile */}
                        <div className="flex items-center gap-3 px-2 py-2">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-gray-200 to-white border border-white shadow-sm flex items-center justify-center text-xs font-bold text-gray-500">
                                OP
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="text-xs font-bold text-[#3A3836]">Operator 1</div>
                                <div className="text-[10px] text-[#8A8886]">Factory 7 Admin</div>
                            </div>
                            <button className="text-[#8A8886] hover:text-[#FF5500] transition-colors">
                                <LogOut size={16} />
                            </button>
                        </div>
                    </div>
                </aside>

                {/* --- MAIN CONTENT --- */}
                <main className="flex-1 flex flex-col relative min-w-0 bg-[#F5F2EB]">
                    
                    {/* Mobile Header */}
                    <header className="md:hidden flex items-center justify-between p-4 bg-[#F5F2EB]/90 backdrop-blur-md sticky top-0 z-30 border-b border-black/5">
                         <div className="flex items-center gap-2">
                            <BrandLogo size={28} />
                            <span className="text-sm font-bold text-[#3A3836] font-serif italic">Factory 7</span>
                        </div>
                        <button 
                            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                            className="p-2 bg-white rounded-xl shadow-sm border border-gray-100"
                        >
                            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
                        </button>
                    </header>

                    <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 md:p-8 custom-scrollbar">
                        <div className="max-w-7xl mx-auto h-full">
                            {activeView === 'DASHBOARD' && <DashboardView onAskAssistant={handleAskAssistant} />}
                            {activeView === 'MEDIA' && <MediaManager />}
                            {activeView === 'DESIGN' && <DesignConcept settings={designSettings} />}
                            {activeView === 'AUDIO' && <AudioStudio settings={audioSettings} />}
                        </div>
                    </div>

                    {/* --- CHAT OVERLAY (Floating Bottom Right) --- */}
                    <div 
                        className={`
                            fixed bottom-6 right-6 w-[90vw] md:w-[400px] bg-white/80 backdrop-blur-2xl border border-white/60 shadow-[0_20px_50px_-12px_rgba(0,0,0,0.15)] rounded-[32px] overflow-hidden transition-all duration-500 cubic-bezier(0.16, 1, 0.3, 1) z-50
                            ${isChatOpen ? 'h-[600px] translate-y-0 opacity-100' : 'h-0 translate-y-12 opacity-0 pointer-events-none'}
                        `}
                    >
                        {/* Chat Header */}
                        <div 
                            className="absolute top-0 left-0 right-0 h-14 flex items-center justify-between px-6 bg-gradient-to-b from-white/50 to-transparent z-10 cursor-pointer"
                            onClick={() => setIsChatOpen(false)}
                        >
                            <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                                <span className="text-xs font-bold text-[#3A3836] uppercase tracking-wider">AI Ops Assistant</span>
                            </div>
                            <button className="p-1 rounded-full hover:bg-black/5 transition-colors">
                                <ChevronDown size={18} className="text-[#8A8886]" />
                            </button>
                        </div>

                        <AIOpsChat 
                            ref={chatRef} 
                            activeArtifact={activeView}
                            onShowArtifact={(view) => setActiveView(view)} 
                        />
                    </div>

                    {/* Chat Toggle Button (Visible when chat is closed) */}
                    <button 
                        onClick={() => setIsChatOpen(true)}
                        className={`
                            fixed bottom-6 right-6 w-14 h-14 bg-[#3A3836] text-[#F5F2EB] rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 z-40 hover:scale-105 active:scale-95
                            ${isChatOpen ? 'scale-0 opacity-0' : 'scale-100 opacity-100'}
                        `}
                    >
                        <MessageSquare size={24} fill="currentColor" className="text-[#F5F2EB]" />
                    </button>

                </main>

                {/* Mobile Menu Backdrop */}
                {isMobileMenuOpen && (
                    <div 
                        className="fixed inset-0 bg-black/20 backdrop-blur-sm z-30 md:hidden animate-in fade-in"
                        onClick={() => setIsMobileMenuOpen(false)}
                    />
                )}
            </div>
        </LiveSystemProvider>
    );
};