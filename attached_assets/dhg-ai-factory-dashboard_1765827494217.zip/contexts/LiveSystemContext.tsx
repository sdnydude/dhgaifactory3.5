
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  SystemMetrics, RegistryEvent, ServiceHealth, RegistryMedia, MediaStatus, ServiceState
} from '../types';
import { MOCK_METRICS, MOCK_SERVICES, MOCK_MEDIA, MOCK_LOGS } from '../services/mockData';

// --- Configuration ---
// In production, these should be set via environment variables
const API_GATEWAY_URL = 'http://localhost:8000'; 
// Set this to false in your 'transfer prompt' target environment to enable real calls
const SIMULATION_MODE = true; 

interface LiveSystemContextType {
  // --- Observability (Prometheus/Grafana equivalent) ---
  metrics: SystemMetrics;
  services: ServiceHealth[];
  events: RegistryEvent[]; // The 'events' table stream

  // --- Registry (PostgreSQL equivalent) ---
  mediaItems: RegistryMedia[];
  
  // --- Orchestrator Actions (LangGraph Triggers) ---
  // Workflow: register_media -> run_asr
  registerMedia: (file: File) => Promise<void>; 
  
  // Workflow: Administrative
  restartService: (serviceName: string) => Promise<void>;
  updateMediaStatus: (id: string, status: MediaStatus) => Promise<void>;
  
  // --- Helpers ---
  addLog: (level: 'INFO' | 'WARN' | 'ERROR', service: string, message: string) => void;
}

const LiveSystemContext = createContext<LiveSystemContextType | undefined>(undefined);

export const useLiveSystem = () => {
  const context = useContext(LiveSystemContext);
  if (!context) {
    throw new Error('useLiveSystem must be used within a LiveSystemProvider');
  }
  return context;
};

export const LiveSystemProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // --- State Stores ---
  const [metrics, setMetrics] = useState<SystemMetrics>(MOCK_METRICS);
  const [events, setEvents] = useState<RegistryEvent[]>(MOCK_LOGS);
  const [services, setServices] = useState<ServiceHealth[]>(MOCK_SERVICES);
  const [mediaItems, setMediaItems] = useState<RegistryMedia[]>(MOCK_MEDIA);

  // --- Helpers ---
  
  const generateUUID = () => crypto.randomUUID();

  // Simulate receiving an event from the backend (or actually receiving one via SSE)
  const emitEvent = useCallback((service: string, type: string, payload: any, correlationId?: string, level: 'INFO'|'WARN'|'ERROR' = 'INFO', message?: string) => {
    const newEvent: RegistryEvent = {
        id: generateUUID(),
        created_at: new Date().toLocaleTimeString('en-US', { hour12: false }),
        source_service: service,
        event_type: type,
        payload: payload,
        correlation_id: correlationId || generateUUID(),
        level,
        message: message || `Event: ${type}`
    };
    setEvents(prev => [newEvent, ...prev].slice(0, 100));
  }, []);

  const addLog = useCallback((level: 'INFO' | 'WARN' | 'ERROR', service: string, message: string) => {
    emitEvent(service, 'LOG_EMIT', { message }, undefined, level, message);
  }, [emitEvent]);

  // --- API Actions ---

  const registerMedia = useCallback(async (file: File) => {
    const correlationId = generateUUID();
    
    // 1. Prepare Payload matching 'media' table schema
    const newMedia: RegistryMedia = {
        id: generateUUID(),
        uri: `s3://dhg-bucket/raw/${file.name.replace(/\s+/g, '_').toLowerCase()}`,
        source_type: file.type || 'application/octet-stream',
        status: MediaStatus.PENDING,
        duration_seconds: 0, 
        metadata: {
            original_name: file.name,
            size_bytes: file.size,
            uploaded_by: 'dhg-web-ui'
        },
        created_at: new Date().toISOString()
    };

    if (!SIMULATION_MODE) {
        // --- REAL PATH: Call API Gateway ---
        try {
            const response = await fetch(`${API_GATEWAY_URL}/media`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newMedia)
            });
            if (!response.ok) throw new Error('API call failed');
            // Optimistic update
            setMediaItems(prev => [newMedia, ...prev]);
        } catch (e) {
            console.error("API Gateway unavailable", e);
            addLog('ERROR', 'dhg-web-ui', 'Failed to connect to API Gateway');
            return;
        }
    } else {
        // --- SIMULATION PATH: Optimistic Update & Mock Workflow ---
        // This simulates the behavior of the 'dhg-orchestrator' Docker container
        
        emitEvent('dhg-web-ui', 'MEDIA_REGISTERED', { media_id: newMedia.id }, correlationId, 'INFO', `Registered media: ${newMedia.id}`);
        setMediaItems(prev => [newMedia, ...prev]);

        // Step 1: Orchestrator picks up job
        setTimeout(() => {
            emitEvent('dhg-orchestrator', 'WORKFLOW_START', { workflow: 'ingest_and_transcribe', media_id: newMedia.id }, correlationId, 'INFO', 'Workflow started: Ingest & Transcribe');
            setMediaItems(prev => prev.map(m => m.id === newMedia.id ? { ...m, status: MediaStatus.PROCESSING } : m));
        }, 1000);

        // Step 2: ASR Service processes
        setTimeout(() => {
            emitEvent('dhg-asr-service', 'GPU_ALLOCATED', { device: 'cuda:0', vram_usage: '4.2GB' }, correlationId, 'INFO', 'Allocated GPU [CUDA:0]');
        }, 2000);

        // Step 3: Write Transcripts & Segments (Vector Embeddings)
        setTimeout(() => {
            const transcriptId = generateUUID();
            emitEvent('dhg-registry-db', 'DB_WRITE', { table: 'transcripts', id: transcriptId }, correlationId, 'INFO', 'Committed transcript to DB');
            emitEvent('dhg-registry-db', 'DB_WRITE', { table: 'segments', count: 12, vector_dim: 1536 }, correlationId, 'INFO', 'Vector embeddings indexed');
            
            setMediaItems(prev => prev.map(m => m.id === newMedia.id ? { 
                ...m, 
                status: MediaStatus.COMPLETED,
                duration_seconds: Math.floor(Math.random() * 300) + 60,
                metadata: { ...m.metadata, resolution: '1080p', codec: 'h264' } 
            } : m));

            emitEvent('dhg-orchestrator', 'WORKFLOW_COMPLETE', { media_id: newMedia.id, duration_ms: 4500 }, correlationId, 'INFO', 'Job completed successfully');
        }, 4500);
    }
  }, [emitEvent, addLog]);

  const updateMediaStatus = useCallback(async (id: string, status: MediaStatus) => {
    if (!SIMULATION_MODE) {
        // Call PATCH /media/:id
    } else {
        setMediaItems(prev => prev.map(i => i.id === id ? { ...i, status } : i));
        emitEvent('dhg-web-ui', 'STATUS_OVERRIDE', { media_id: id, new_status: status }, undefined, 'WARN', `Manual status override: ${status}`);
    }
  }, [emitEvent]);

  const restartService = useCallback(async (serviceName: string) => {
    emitEvent('dhg-ops-admin', 'RESTART_REQUESTED', { service: serviceName }, undefined, 'WARN', `Restarting ${serviceName}...`);
    
    // Simulate Lifecycle
    setServices(prev => prev.map(s => s.name === serviceName ? { ...s, status: ServiceState.DOWN } : s));
    
    setTimeout(() => {
         setServices(prev => prev.map(s => s.name === serviceName ? { ...s, status: ServiceState.HEALTHY } : s));
         emitEvent(serviceName, 'SERVICE_RECOVERED', { uptime: '0s' }, undefined, 'INFO', `${serviceName} online and healthy`);
    }, 2000);
  }, [emitEvent]);


  // --- Simulation Loop (Heartbeat) ---
  useEffect(() => {
    if (!SIMULATION_MODE) return;

    const interval = setInterval(() => {
      // 1. Update Metrics (Random Walk)
      setMetrics(prev => {
        const updateSeries = (series: {time: string, value: number}[], baseValue: number, variance: number) => {
          const newTime = new Date();
          const timeLabel = `${newTime.getHours()}:${newTime.getMinutes() < 10 ? '0'+newTime.getMinutes() : newTime.getMinutes()}:${newTime.getSeconds() < 10 ? '0'+newTime.getSeconds() : newTime.getSeconds()}`;
          const lastValue = series[series.length - 1].value;
          let newValue = lastValue + (Math.random() - 0.5) * variance;
          newValue = Math.max(10, Math.min(baseValue * 2, newValue));
          return [...series.slice(1), { time: timeLabel, value: Math.floor(newValue) }];
        };

        return {
          gpuUtilization: updateSeries(prev.gpuUtilization, 60, 15),
          asrLatency: updateSeries(prev.asrLatency, 400, 50),
          registryWrites: updateSeries(prev.registryWrites, 50, 20),
          orchestratorQueue: updateSeries(prev.orchestratorQueue, 5, 2),
        };
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <LiveSystemContext.Provider value={{
        metrics,
        events,
        services,
        mediaItems,
        addLog,
        registerMedia,
        updateMediaStatus,
        restartService
    }}>
        {children}
    </LiveSystemContext.Provider>
  );
};
