
import { MediaStatus, RegistryMedia, ServiceHealth, ServiceState, RegistryEvent, SystemMetrics } from '../types';

export const TARGET_PLATFORMS = [
    { id: 'spotify', label: 'Spotify', lufs: -14, peak: -1.0 },
    { id: 'apple', label: 'Apple Podcasts', lufs: -16, peak: -1.0 },
    { id: 'youtube', label: 'YouTube', lufs: -14, peak: -1.0 },
    { id: 'cd', label: 'CD Standard', lufs: -9, peak: -0.1 },
    { id: 'broadcast', label: 'EBU R128 (Broadcast)', lufs: -23, peak: -1.0 },
];

export const MOCK_SERVICES: ServiceHealth[] = [
  { name: 'dhg-registry-db', status: ServiceState.HEALTHY, latencyMs: 12, uptime: '99.99%', version: '1.2.0' },
  { name: 'dhg-asr-service', status: ServiceState.HEALTHY, latencyMs: 450, uptime: '99.95%', version: '2.4.1' },
  { name: 'dhg-orchestrator', status: ServiceState.DEGRADED, latencyMs: 120, uptime: '98.50%', version: '0.9.5' },
  { name: 'dhg-api-gateway', status: ServiceState.HEALTHY, latencyMs: 5, uptime: '100%', version: '3.0.0' },
  { name: 'dhg-gpu-exporter', status: ServiceState.HEALTHY, latencyMs: 2, uptime: '99.99%', version: '1.0.1' },
];

export const MOCK_MEDIA: RegistryMedia[] = [
  { 
    id: 'uuid-1', 
    uri: 's3://dhg-bucket/raw/meeting_01.wav', 
    source_type: 'audio/wav', 
    status: MediaStatus.COMPLETED, 
    duration_seconds: 345, 
    created_at: '2023-10-25T10:00:00Z', 
    metadata: { transcript_snippet: "Okay, let's start the deployment planning meeting..." } 
  },
  { 
    id: 'uuid-2', 
    uri: 's3://dhg-bucket/raw/interview_robert.mp3', 
    source_type: 'audio/mp3', 
    status: MediaStatus.PROCESSING, 
    duration_seconds: 1205, 
    created_at: '2023-10-25T11:30:00Z', 
    metadata: {} 
  },
  { 
    id: 'uuid-3', 
    uri: 's3://dhg-bucket/raw/error_log_dump.mp4', 
    source_type: 'video/mp4', 
    status: MediaStatus.FAILED, 
    duration_seconds: 0, 
    created_at: '2023-10-25T12:00:00Z', 
    metadata: { error_code: 'ERR_DECODE_FAIL' } 
  },
  { 
    id: 'uuid-4', 
    uri: 's3://dhg-bucket/raw/customer_call_88.wav', 
    source_type: 'audio/wav', 
    status: MediaStatus.PENDING, 
    duration_seconds: 88, 
    created_at: '2023-10-25T12:15:00Z', 
    metadata: {} 
  },
  { 
    id: 'uuid-5', 
    uri: 's3://dhg-bucket/raw/daily_standup.wav', 
    source_type: 'audio/wav', 
    status: MediaStatus.COMPLETED, 
    duration_seconds: 900, 
    created_at: '2023-10-25T09:00:00Z', 
    metadata: { transcript_snippet: "Yesterday I worked on the registry schema migrations..." } 
  },
];

export const MOCK_LOGS: RegistryEvent[] = [
  { id: 'evt-1', created_at: '10:00:01', source_service: 'dhg-orchestrator', event_type: 'JOB_REGISTER', level: 'INFO', message: 'Job registered for uuid-1', payload: {} },
  { id: 'evt-2', created_at: '10:00:05', source_service: 'dhg-asr-service', event_type: 'GPU_LOCK', level: 'INFO', message: 'GPU locked for transcription', payload: {} },
  { id: 'evt-3', created_at: '11:30:00', source_service: 'dhg-registry-db', event_type: 'CONN_POOL', level: 'WARN', message: 'Connection pool reaching capacity', payload: {} },
  { id: 'evt-4', created_at: '12:00:01', source_service: 'dhg-asr-service', event_type: 'CUDA_OOM', level: 'ERROR', message: 'CUDA OutOfMemoryError on device 0', payload: {} },
];

// Generate some trend data
export const MOCK_METRICS: SystemMetrics = {
  gpuUtilization: Array.from({ length: 20 }, (_, i) => ({ time: `${10 + i}:00`, value: Math.floor(Math.random() * 60) + 20 })),
  asrLatency: Array.from({ length: 20 }, (_, i) => ({ time: `${10 + i}:00`, value: Math.floor(Math.random() * 200) + 300 })),
  registryWrites: Array.from({ length: 20 }, (_, i) => ({ time: `${10 + i}:00`, value: Math.floor(Math.random() * 100) })),
  orchestratorQueue: Array.from({ length: 20 }, (_, i) => ({ time: `${10 + i}:00`, value: Math.floor(Math.random() * 10) })),
};
