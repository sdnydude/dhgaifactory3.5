import { GoogleGenAI } from "@google/genai";
import { MOCK_SERVICES, MOCK_MEDIA, MOCK_LOGS, MOCK_METRICS } from "./mockData";

let aiClient: GoogleGenAI | null = null;

export const initializeGenAI = () => {
  if (process.env.API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
};

export const generateOpsInsight = async (userPrompt: string): Promise<string> => {
  if (!aiClient) {
    initializeGenAI();
    if (!aiClient) return "API Key not found. Please ensure process.env.API_KEY is set.";
  }

  // Build context from the mocked system state
  const systemContext = `
    You are the DHG AI Factory Ops Assistant.
    Current System State:
    - Services: ${JSON.stringify(MOCK_SERVICES)}
    - Recent Media Jobs: ${JSON.stringify(MOCK_MEDIA)}
    - Recent Alert Logs: ${JSON.stringify(MOCK_LOGS)}
    - System Metrics Summary: GPU Util avg ~50%, ASR Latency avg ~400ms.

    Your goal is to help the operator understand the system health, diagnose errors (like the CUDA OOM), and track job status.
    Keep answers concise and technical but friendly. Formatted in Markdown.
  `;

  try {
    const response = await aiClient!.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        { role: 'user', parts: [{ text: systemContext }] },
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
    });

    return response.text || "No response generated.";
  } catch (error) {
    console.error("GenAI Error:", error);
    return "I encountered an error connecting to the AI brain. Please check your network or API key.";
  }
};

export const generateDesignMockup = async (
  variationSeed: number = 0, 
  themeMode: 'light' | 'dark' = 'dark',
  innovationLevel: number = 50,
  style: string = 'Glassmorphism',
  interfaceType: string = 'Dashboard',
  aspectRatio: string = '16:9',
  customPrompt: string = '',
  colorPalette: string = 'DHG System'
): Promise<string | null> => {
  if (!aiClient) {
    initializeGenAI();
    if (!aiClient) throw new Error("API Key not found");
  }

  const themeConfig = themeMode === 'light' 
    ? `LIGHT MODE: Bright, airy, high-key lighting. Background #F4F2ED. High contrast dark ink text.` 
    : `DARK MODE: Deep, cinematic, low-key lighting. Background #0F0F12. Glowing accents.`;

  const chaosFactor = innovationLevel > 70 
    ? "CREATIVITY: EXTREME / AVANT-GARDE. Break the grid. Use fluid organic shapes, asymmetry, and unexpected playful interactions. Make it feel alive and futuristic." 
    : "CREATIVITY: REFINED / STRICT. Perfect alignment, standard grid, symmetry, and calm. Enterprise-grade polish.";

  // Palette definitions mapping
  let paletteInstruction = "";
  if (colorPalette === 'DHG System') {
    paletteInstruction = "COLOR PALETTE: Use the 'DHG Brand' colors: Warm Stone (#F5F2EB), Blaze Orange (#FF5500), and Charcoal (#3A3836). Use the Orange for primary actions and accents.";
  } else if (colorPalette === 'Midnight') {
    paletteInstruction = "COLOR PALETTE: Deep blues, purples, and neon cyan accents.";
  } else if (colorPalette === 'Electric') {
    paletteInstruction = "COLOR PALETTE: High saturation neons, acid green, hot pink on black.";
  } else if (colorPalette === 'Pastel') {
    paletteInstruction = "COLOR PALETTE: Soft muted tones, mint green, baby blue, lavender.";
  } else if (colorPalette === 'Monochrome') {
    paletteInstruction = "COLOR PALETTE: Greyscale, silver, chrome, and white.";
  }

  const prompt = `
    Create a high-fidelity UI UX design mockup.
    
    INTERFACE TYPE: ${interfaceType}
    DESIGN STYLE: ${style}
    ${themeConfig}
    ${chaosFactor}
    ${paletteInstruction}
    
    ASPECT RATIO TARGET: ${aspectRatio}

    USER CREATIVE BRIEF / CONTEXT: "${customPrompt}"

    CONTENT CONTEXT:
    The app is "DHG AI Factory".
    
    REQUIRED UI ELEMENTS:
    1. A prominent "Daily Innovation Streak" counter.
    2. A "Level Up" progress bar for system intelligence.
    3. Complex data visualizations (charts, nodes, or waveforms) fitting the '${style}' aesthetic.
    4. Floating navigation elements.

    VISUAL DETAILS:
    - If 'Glassmorphism': Use heavy blur, frosted glass, layered depth, white borders.
    - If 'Neo-Brutalism': Use hard black borders, vibrant flat colors, brutal typography, shadows.
    - If 'Cyberpunk': Use neon glown, chromatic aberration, glar, HUD elements.
    - If 'Swiss Minimal': Use massive typography, negative space, grid-based layout, Helvetica.
    - If 'Social Media': Make it look like a high-engagement Instagram/LinkedIn post template promoting the brand.

    Render photorealistic 8k resolution.
    VARIATION SEED: ${variationSeed}.
  `;

  try {
    // using nano banana model as requested for image generation
    const response = await aiClient!.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }]
      },
    });

    // Extract image from response
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image Gen Error:", error);
    throw error;
  }
};