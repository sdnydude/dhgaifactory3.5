# Vector Storage & GraphRAG Implementation Plan

## Overview

Transform DHG AI Factory into the first AI-powered CME platform with patent-worthy cross-program pattern recognition and multi-agent knowledge synthesis.

**Timeline**: 6 weeks  
**Cost**: ~$1,000 (mostly LightRAG indexing)  
**Outcome**: Competitive moat via GraphRAG capabilities

---

## Phase 1: pgvector Foundation (Week 1)

### Goal
Enable semantic search on CR database without data duplication.

### Technical Implementation

#### 1.1 Database Extensions
```sql
-- On server .251, connect to CR database
ssh -i ~/.ssh/id_ed25519_fafstudios swebber64@10.0.0.251

docker exec -it dhg-registry-db psql -U dhg -d dhg_registry

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;  -- for hybrid search
```

#### 1.2 Schema Updates
```sql
-- Add vector columns (384 dimensions for all-MiniLM-L6-v2)
ALTER TABLE antigravity_messages 
ADD COLUMN embedding vector(384);

ALTER TABLE antigravity_chats 
ADD COLUMN summary_embedding vector(384);

-- Create indexes
CREATE INDEX ON antigravity_messages 
USING ivfflat (embedding vector_cosine_ops) 
WITH (lists = 100);

CREATE INDEX ON antigravity_chats 
USING ivfflat (summary_embedding vector_cosine_ops) 
WITH (lists = 50);
```

#### 1.3 Embedding Service
```python
# /home/swebber64/DHG/aifactory3.5/dhgaifactory3.5/registry/embedding_service.py

from sentence_transformers import SentenceTransformer
import psycopg2

model = SentenceTransformer('all-MiniLM-L6-v2')

def generate_embedding(text: str) -> list:
    """Generate 384-dim embedding"""
    return model.encode(text).tolist()

# Auto-vectorization trigger
CREATE OR REPLACE FUNCTION vectorize_message()
RETURNS TRIGGER AS $$
DECLARE
    embedding_result vector(384);
BEGIN
    -- Call Python service to generate embedding
    embedding_result := generate_embedding_from_service(NEW.content);
    NEW.embedding := embedding_result;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER message_auto_vectorize
BEFORE INSERT OR UPDATE ON antigravity_messages
FOR EACH ROW EXECUTE FUNCTION vectorize_message();
```

#### 1.4 Search API
```python
# registry/api.py - add endpoint

@app.post("/api/search/semantic")
def semantic_search(query: str, limit: int = 10):
    query_embedding = generate_embedding(query)
    
    results = db.execute("""
        SELECT id, content, 
               1 - (embedding <=> %s::vector) as similarity
        FROM antigravity_messages
        WHERE embedding IS NOT NULL
        ORDER BY embedding <=> %s::vector
        LIMIT %s
    """, (query_embedding, query_embedding, limit))
    
    return results
```

**Deliverables:**
- [ ] pgvector enabled on CR
- [ ] Vector columns added
- [ ] Embedding service running
- [ ] Search API tested

**Success Criteria:**
- Search returns results in <100ms
- Baseline similarity accuracy validated

---

## Phase 2: Onyx Integration (Week 2)

### Goal
Configure Onyx to use CR database, eliminating data duplication.

### Technical Implementation

#### 2.1 Onyx Configuration
```yaml
# infrastructure/docker-compose.yml

services:
  onyx-backend:
    environment:
      # Use PostgreSQL instead of Vespa
      VECTOR_DB_TYPE: postgres
      POSTGRES_HOST: dhg-registry-db
      POSTGRES_PORT: 5432
      POSTGRES_USER: dhg
      POSTGRES_PASSWORD: weenie64
      POSTGRES_DB: dhg_registry
      
      # Onyx will create these tables in CR:
      # - document_chunks
      # - document_embeddings  
      # - connector_metadata
```

#### 2.2 Connector Setup
```python
# Configure Onyx to sync from CR

POST http://localhost:3001/api/manage/admin/connector
{
  "name": "CR Antigravity Sessions",
  "type": "postgres",
  "config": {
    "host": "dhg-registry-db",
    "database": "dhg_registry",
    "table": "antigravity_messages",
    "sync_frequency": "hourly"
  }
}
```

#### 2.3 Validation
```bash
# Verify no data duplication
docker exec dhg-registry-db psql -U dhg -d dhg_registry -c "
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables
WHERE tablename LIKE '%antigravity%' OR tablename LIKE '%document%'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
"
```

**Deliverables:**
- [ ] Onyx configured for PostgreSQL
- [ ] Onyx tables created in CR
- [ ] Connector syncing CR data
- [ ] UI search working

**Success Criteria:**
- Single database confirmed
- Onyx search matches direct pgvector results

---

## Phase 3: LightRAG Integration (Week 3-4)

### Goal
Enable multi-hop reasoning and cross-session pattern recognition.

### Technical Implementation

#### 3.1 Installation
```bash
ssh -i ~/.ssh/id_ed25519_fafstudios swebber64@10.0.0.251

cd /home/swebber64/DHG/aifactory3.5/dhgaifactory3.5

# Install LightRAG
pip install lightrag

# Or from source for latest features
git clone https://github.com/HKUDS/LightRAG
cd LightRAG && pip install -e .
```

#### 3.2 Configuration
```python
#registry/graphrag_service.py

from lightrag import LightRAG
import os

rag = LightRAG(
    working_dir="./graphrag_index",
    
    # Use PostgreSQL for storage
    storage_backend="postgres",
    postgres_url="postgresql://dhg:weenie64@localhost:5432/dhg_registry",
    
    # LLM config
    llm_model="claude-3-haiku-20240307",  # Cost-effective
    embedding_model="text-embedding-3-small",
    
    # GraphRAG-specific
    entity_types=["Project", "Agent", "File", "Concept", "Person", 
                  "TherapeuticArea", "ComplianceIssue", "ClinicalGap"],
    
    # Enable incremental updates
    enable_incremental=True
)
```

#### 3.3 Indexing Pipeline
```python
def index_antigravity_sessions(limit=None):
    """Index sessions into LightRAG knowledge graph"""
    
    sessions = db.execute("""
        SELECT c.id, c.title, 
               array_agg(m.content ORDER BY m.created_at) as messages
        FROM antigravity_chats c
        JOIN antigravity_messages m ON m.chat_id = c.id
        GROUP BY c.id
        LIMIT %s
    """, (limit,))
    
    total_cost = 0
    
    for session in sessions:
        # Combine messages into document
        document = f"# {session.title}\n\n" + "\n\n".join(session.messages)
        
        # Index (calls LLM for entity extraction)
        result = rag.insert(document)
        
        total_cost += result.cost
        
        print(f"Indexed {session.id}: ${result.cost:.4f}")
    
    print(f"\nTotal indexing cost: ${total_cost:.2f}")
    return total_cost
```

#### 3.4 Smart Query Routing
```python
def intelligent_search(query: str):
    """Route to best search method"""
    
    # Simple similarity queries → pgvector
    if is_simple_query(query):
        return pgvector_search(query)
    
    # Complex multi-hop → LightRAG global search
    elif requires_synthesis(query):
        return rag.query(query, mode="global")
    
    # Entity-specific → LightRAG local search
    else:
        return rag.query(query, mode="local")

def is_simple_query(q):
    """Detect simple similarity searches"""
    simple_patterns = ["similar to", "like this", "find"]
    return any(p in q.lower() for p in simple_patterns)

def requires_synthesis(q):
    """Detect queries needing cross-document synthesis"""
    synthesis_patterns = ["patterns", "across all", "trend", "emerge"]
    return any(p in q.lower() for p in synthesis_patterns)
```

**Deliverables:**
- [ ] LightRAG installed and configured
- [ ] First 100 sessions indexed
- [ ] Query routing implemented
- [ ] Cost tracking enabled

**Success Criteria:**
- Indexing cost <$150 for 100 sessions
- Multi-hop queries return synthesized answers
- Query latency <3s for complex queries

---

## Phase 4: Patent Documentation (Week 4-5)

### Goal
Document novel workflows for patent applications.

### Patent-Worthy Claims

#### Claim 1: Multi-Modal CME Knowledge Graph
```
System for generating continuing medical education content comprising:
- Autonomous agents specialized by therapeutic area
- Knowledge graph linking research, content, outcomes, and compliance
- Sub-agent spawning based on clinical domain classification
- Cross-modal evidence synthesis (video, text, audio, interactions)
```

**Novelty**: No existing CME platform uses multi-agent knowledge graphs

#### Claim 2: Compliance Pattern Detection
```
Method for detecting regulatory compliance issues in medical education:
- Graph-based pattern matching across historical CME programs
- Entity relationship extraction from ACCME requirements
- Automated flagging of potential violations before submission
- Learning from past rejections to prevent future issues
```

**Novelty**: Automated compliance via graph patterns is unique to CME

#### Claim 3: Dynamic Content Strategy Generation
```
AI system for recommending medical education content strategy:
- Multi-hop reasoning across physician queries, research, and outcomes
- Competitive gap analysis via knowledge graph traversal
- Therapeutic area trend detection through community clustering
- ROI prediction based on historical program performance
```

**Novelty**: Strategic planning automation for CME is unprecedented

### Documentation Requirements

#### Technical Diagrams
1. Multi-agent architecture with knowledge graph
2. Sub-agent spawning decision tree
3. Evidence synthesis flow (research → content)
4. Compliance checking workflow

#### Workflow Examples
```markdown
# Example: Fair Balance Detection Workflow

1. Agent receives pharma sponsor content request
2. Research agent queries knowledge graph:
   - Similar products' CME programs
   - ACCME violations in that therapeutic area
   - Fair balance requirements from past reviews
3. Knowledge graph returns relationship pattern:
   "Product X programs had 3 fair balance issues in cardiovascular space"
4. QA agent flags potential issues BEFORE content creation
5. Compliance agent validates against ACCME standards
6. System documents decision trail for audit

Patent claim: Proactive compliance via historical pattern graphs
```

**Deliverables:**
- [ ] 4+ patent claim drafts
- [ ] Technical workflow diagrams
- [ ] Novel feature documentation
- [ ] Prior art comparison

---

## Phase 5: Pharma Demo (Week 5-6)

### Goal
Prove business value to potential client with live GraphRAG queries.

### Demo Script

#### Setup
- 500+ sessions indexed (diverse therapeutic areas)
- Include real CME programs, compliance cases, physician Q&A
- Prepare 5 killer queries that traditional systems can't answer

#### Demo Flow (30 minutes)

**1. Problem Statement (5 min)**
- CME content creation is manual, slow, reactive
- No institutional memory across programs
- Compliance is reactive, not proactive
- Competitive intelligence is ad-hoc

**2. Show Traditional Approach (5 min)**
- Search for "diabetes CME gaps"
- Get: List of relevant documents
- Problem: Human must read, synthesize, connect patterns

**3. Show GraphRAG Approach (15 min)**

**Query 1: Cross-Program Pattern Recognition**
```python
query = """
Across all Type 2 Diabetes CME programs from 2024-2025:
- What clinical gaps were most frequently identified?
- Which Moore Level outcomes were measured?
- What compliance issues arose?
- How do our gaps differ from competitor programs?
"""

result = rag.query(query, mode="global")
```

**Expected Output:**
```
Analysis of 23 Type 2 Diabetes programs:

Clinical Gaps:
1. GLP-1 agonist use in heart failure (mentioned in 18/23 programs)
2. SGLT2 inhibitor renal protection (14/23)  
3. Hypoglycemia management in elderly (12/23)

Moore Outcomes:
- Level 3 (Competence): 23/23 programs
- Level 4 (Performance): 8/23 programs
- Level 5 (Patient outcomes): 2/23 programs

Compliance Patterns:
- Fair balance issues: 3 programs in 2024 Q2
- All involved cardiovascular safety data presentation
- Same ACCME reviewer flagged similar wording

Competitive Differentiation:
- Competitors focus on medication adherence gaps
- DHG uniquely addresses social determinants (5 programs)
- No competitor addresses Level 5 outcomes
```

**Business Impact**: "This took 2 seconds. Manual analysis would take 2 weeks."

**Query 2: Evidence-Based Content Strategy**
```python
query = """
For NASH/NAFLD therapeutic area:
- What are the latest research developments from PubMed?
- What physician questions have we received?
- What content gaps exist versus competitors?
- Recommend content strategy for 2026
"""
```

**Expected Output:**
```
PubMed Research (past 6 months):
- 47 new MASH treatment trials
- Resmetirom FDA approval (March 2024)
- Focus shifting to fibrosis regression endpoints

Physician Questions (from past CME):
- "How to identify MASH candidates in primary care?" (24 instances)
- "Insurance coverage for new MASH drugs?" (18 instances)
- "Monitoring liver fibrosis progression?" (15 instances)

Competitor Gap Analysis:
- No competitor CME on Resmetirom (opportunity)
- Most content is GI specialist-focused
- Gap: Primary care physician education

2026 Content Recommendation:
1. Create primary care-focused MASH program
2. Address insurance/access questions
3. Include Moore Level 4 (practice change) outcomes
4. Collaborate with payers for access education
```

**Business Impact**: "Strategic insights in seconds, not weeks of analysis."

**Query 3: Compliance Prediction**
```python
query = """
We're creating a CME program on novel GLP-1 agonists for obesity.
Based on past programs:
- What fair balance issues should we anticipate?
- What ACCME violations occurred in similar programs?
- What evidence standards should we apply?
"""
```

**Expected Output:**
```
Historical Compliance Patterns (weight management CME):

Fair Balance Risks:
- 4/7 past programs had issues with outcome claims
- Specific problem: Citing % weight loss without mentioning variance
- ACCME required explicit discussion of non-responders

Evidence Requirements:
- All obesity programs required Level 1 evidence (RCTs)
- Real-world evidence was flagged in 2/7 programs
- Minimum 2 systematic reviews/meta-analyses needed

Recommendations:
1. Include explicit non-responder discussion
2. Cite FDA-approved outcomes only
3. Use peer-reviewed meta-analyses
4. Avoid manufacturer-sponsored studies as primary evidence

Predicted Compliance Score: 92% (based on similar programs)
```

**Business Impact**: "Prevent costly rejections before submission."

**4. ROI Calculation (5 min)**

Show quantified value:
- Time saved: 10 hours/program × $150/hr = $1,500 per program
- Compliance: 1 prevented rejection = $10,000 saved
- Quality: Strategic insights = higher client satisfaction
- Competitive: Unique capability = premium pricing

**Estimated ROI**: $50,000+ value in first year for typical pharma client

**Deliverables:**
- [ ] Demo dataset prepared (500+ sessions)
- [ ] 5 demo queries tested and polished
- [ ] Demo script rehearsed
- [ ] Presentation deck with ROI calculations
- [ ] Pharma client meeting scheduled

---

## Cost Breakdown

| Item | Cost | Notes |
|------|------|-------|
| pgvector | $0 | Uses existing PostgreSQL |
| Onyx setup | $0 | No additional infrastructure |
| LightRAG indexing | $700 | 1000 sessions @ ~$0.70 each |
| LLM queries (demo) | $50 | ~100 test queries |
| Engineer time | Included | Internal resource |
| **Total** | **$750** | One-time cost |

**Ongoing costs:**
- Query costs: ~$50/month (1000 queries)
- New session indexing: ~$100/month (150 sessions)
- Total ongoing: **~$150/month**

---

## Success Metrics

### Technical KPIs
- Vector search latency: <100ms p95
- GraphRAG query latency: <3s
- Indexing cost: <$1 per session
- Query accuracy: >85% for multi-hop questions

### Business KPIs
- Patent applications filed: 3+
- Pharma demos conducted: 1+
- Client feedback: "Wow/game-changing" reaction
- Competitive advantage: Confirmed unique capability

---

## Risks & Mitigation

| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
| LightRAG costs exceed budget | Medium | Medium | Start with 100 sessions, measure costs |
| Performance issues at scale | High | Low | Add pgvectorscale, optimize indexes |
| Demo queries don't impress | High | Low | Prepare 10+ queries, rehearse extensively |
| Patent overlap | Medium | Medium | Focus on CME-specific application |
| Client data privacy concerns | High | Medium | Anonymize data, clear docs on usage |

---

## Next Steps

1. **Review this plan** - Confirm approach and timeline
2. **Approve budget** - $750 one-time + $150/month ongoing
3. **Begin Phase 1** - Start with pgvector setup this week
4. **Schedule checkpoint** - Review after Phase 1 completion

Target demo date: **Week of March 10, 2026**
